import React, { useState, useEffect } from "react";
import { Form, Button, Container, Row, Col } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import Spinner from "react-bootstrap/Spinner";

const AuthApiBaseUrl = import.meta.env.VITE_AUTHENTICATIONAPI_BASE_URL;

const LoginPage = (props) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isValidated, setIsValidated] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    // Any setup logic can go here
  }, []);

  const handleMicrosoftLogin = async () => {
    setIsLoading(true);
    try {
      // Mock a login response
      const mockLoginResponse = {
        account: {
          username: "mockuser@mockdomain.com",
          name: "Mock User",
          homeAccountId: "1234-5678-91011",
          localAccountId: "1234-5678-91011",
        },
        idToken: "mock-id-token",
      };

      console.log("Microsoft Login Mock Response:", mockLoginResponse);

      // Simulate storing the user's account information
      const user = mockLoginResponse.account;
      localStorage.setItem("msalUser", JSON.stringify(user));

      // Simulate post-login actions
      props.handleIsAuthenticated(true);
      navigate("/search");
    } catch (error) {
      console.error("Mock Microsoft login failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const credentials = { email, password };

    setIsLoading(true);
    fetch(`${AuthApiBaseUrl}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(credentials),
    })
      .then((response) => {
        if (!response.ok) {
          setIsValidated(false);
          return;
        }
        return response.json();
      })
      .then((data) => {
        localStorage.setItem("user", JSON.stringify(data.result));
        props.handleIsAuthenticated(true);
        navigate("/search");
      })
      .catch((error) => console.error("Error:", error))
      .finally(() => setIsLoading(false));
  };

  return (
    <Row className="p-5">
      <Col>
        <Container className="mt-5">
          {isLoading && (
            <Spinner animation="border" role="status">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
          )}
          <Form style={{ maxWidth: "400px", margin: "0 auto" }} onSubmit={handleSubmit}>
            <img src="/Valmet.png" className="mb-4" style={{ width: "200px" }} alt="" />
            {!isValidated && <h6 style={{ color: "red" }}>Username or Password is invalid</h6>}

            <Form.Group controlId="formBasicEmail">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </Form.Group>

            <Form.Group controlId="formBasicPassword">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </Form.Group>

            <Button variant="success" type="submit" className="mt-3">
              Login
            </Button>

            <Button variant="primary" className="mt-3 ms-3" onClick={handleMicrosoftLogin}>
              Login with Microsoft
            </Button>
          </Form>
        </Container>
      </Col>
    </Row>
  );
};

export default LoginPage;
