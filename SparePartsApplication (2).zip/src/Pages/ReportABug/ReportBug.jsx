import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Bug } from "lucide-react";
import { toast } from "react-toastify";

const ReportBug = () => {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    severity: "",
    reportedBy: "",
  });

  const PRICINGAPI_BASE_URL =
    "https://wea-spt-use-dv-pricingapi-001.azurewebsites.net";


  // Get email from localStorage on load
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser?.user?.email) {
      setFormData((prev) => ({
        ...prev,
        reportedBy: storedUser.user.email,
      }));
    }
  }, []);

  const handleChange = (e) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log("Bug reported:", formData);
    // Here you would typically send the formData to your backend API
    // For demonstration, we'll just log it to the console

    // Example API call (uncomment and modify as needed):
     const response = await fetch(
       `${PRICINGAPI_BASE_URL}/reportBug`,
       {
         method: "POST",
         headers: {
           "Content-Type": "application/json",
         },
         body: JSON.stringify(formData),
       }
     ); 

     if (!response.ok) {
       toast.error("Failed to submit bug. Please try again.");
       return;
     }
    toast.success("Bug successfully submitted!");

    setFormData({
      title: "",
      description: "",
      severity: "",
      reportedBy: formData.reportedBy, // keep email after reset
    });
  };

  return (
    <div className="min-h-[calc(100vh-90px)] pt-[120px] flex justify-center px-4 ">
      <Card className="shadow-md w-full max-w-2xl">
        <CardContent className="p-6 space-y-6">
          <h2 className="text-2xl font-semibold flex items-center gap-2">
            <Bug className="text-red-500" />
            Report a Bug
          </h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">
                Bug Title
              </label>
              <Input
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
                placeholder="e.g., Crash on Save"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">
                Description
              </label>
              <Textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
                rows={4}
                placeholder="Describe how to reproduce the bug..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Severity</label>
              <select
                name="severity"
                value={formData.severity}
                onChange={handleChange}
                required
                className="w-full rounded-md border px-3 py-2 text-sm"
              >
                <option value="">Select Severity</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
                <option value="Critical">Critical</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">
                Your Email
              </label>
              <Input
                name="reportedBy"
                value={formData.reportedBy}
                disabled
                className="cursor-not-allowed bg-gray-100"
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-red-500 hover:bg-red-600 text-white"
            >
              Submit Bug
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReportBug;
