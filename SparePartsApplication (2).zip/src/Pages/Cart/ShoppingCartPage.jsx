import Container from "react-bootstrap/Container";
import React, { useEffect, useRef } from "react";

import { Row, Col } from "react-bootstrap";
import Table from "react-bootstrap/Table";
import {
  addItem,
  removeItem,
  updateQuantity,
  clearCart,
  getTotals
} from "../../Redux/cartSlice";

import CheckoutItem from "./CheckoutItem/CheckoutItem";
import Subtotal from "./CheckoutItem/Subtotal";
import "./ShoppingCart.css";
import { use } from "i18next";
import { useDispatch, useSelector } from "react-redux";

import TableRow from "./Table/TableRow";

function ShoppingCartPage() {
  const items = useSelector((state) => state.cart.items);
  const cart = useSelector((state) => state.cart);
  const dispatch = useDispatch();

  useEffect(()=> {
    dispatch(getTotals())
  }, [items , dispatch])

  let USDollar = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  });

  return (
    <div style={{ marginTop: "90px", overflowX: "hidden" }}>
      <Row className="p-5">
        <Col
          xs={8}
          style={{ overflow: "auto", height: "900px" }}
          className="p-0 mt-5 mb-4"
        >
          {items.length === 0 ? (
            <div>
              <h1>Add Line Items to Get More Information ... </h1>
            </div>
          ) : (
            <>
              <div style={{ maxHeight: "500px", overflow: "auto" }}>
                <Table
                  responsive
                  striped
                  hover
                  bordered
                  style={{
                    fontSize: "12px",
                    textAlign: "center",
                  }}
                >
                  <thead style={{ fontSize: "15px" }}>
                    <tr>
                      <th>MLFB / Part Name</th>
                      <th>Part Number</th>
                      <th>Quantity</th>
                      <th>Remove</th>
                      <th>Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((item, index) => (
                      // <CheckoutItem
                      //   key={item.id}
                      //   name={item.name}
                      //   partNumber={item.partNumber}
                      //   image={item.image}
                      //   description={item.description}
                      //   price={item.price}
                      // />
                      <TableRow key={index} item={item} />
                    ))}
                  </tbody>
                </Table>
              </div>

              <Table
                responsive
                hover
                bordered
                variant="dark"
                style={{
                  fontSize: "12px",
                  textAlign: "center",
                  float: "right",
                  marginRight: "2px",
                }}
              >
                <thead style={{ fontSize: "12px", fontWeight: "bold" }}>
                  <tr>
                    <td></td>
                    <td style={{ textAlign: "right" }}>Tax</td>
                    <td style={{ textAlign: "right", padding: "8px" }}>
                      $0.00
                    </td>
                  </tr>

                  <tr>
                    <td></td>
                    <td style={{ textAlign: "right" }}>Total</td>
                    <td
                      style={{
                        textAlign: "right",
                        padding: "8px",
                        width: "200px",
                      }}
                    >
                      {USDollar.format(cart.cartTotalAmount)}
                    </td>
                  </tr>
                </thead>
              </Table>
            </>
          )}
        </Col>
        <Col className="p-0 mt-5 mb-4">
          <Subtotal />
        </Col>
      </Row>
    </div>
  );
}

export default ShoppingCartPage;
