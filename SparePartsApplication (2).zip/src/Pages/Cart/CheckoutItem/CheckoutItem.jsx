import React from "react";

import Button from "react-bootstrap/Button";

import { useStateValue } from "../../../Redux/stateProvider";

const styles = {
  checkoutItem: {
    border: "1px solid #ccc",
    borderRadius: "8px",
    padding: "40px",
    margin: "20px",
    display: "flex",
   
  },
  checkoutItemImage: {
    width: "100px",
    height: "100px",
    marginRight: "10px",
  },
  checkoutItemDetails: {
    flex: "1",
  },
  removeButton: {
    float: 'right',
    fontSize: '11px'
  }
};

const CheckoutItem = (props) => {
  const [{ basket }, dispatch] = useStateValue();

  const removeFromBasket = () => {
    //Remove from the basket
    dispatch({
      type: "Remove_from_Basket",
      name: name,
    });
  };

  return (
    <div className="checkout-item" style={styles.checkoutItem}>
      <div className="checkout-item-details" style={styles.checkoutItemDetails}>
        <div className="checkout-item-image" style={styles.checkoutItemImage}>
          <img src={props.image} alt="" />
        </div>
        <h3 style={{ fontSize: '14px'}}>{props.name}</h3>
        <p style={{ fontSize: '12px'}}> Part Number: {props.partNumber}</p>
        <p style={{ fontSize: '11px'}}> Quantity: 1</p>
        <p style={{ fontSize: '10px'}}>Price: ${props.price}</p>
        <Button variant="warning" onClick={removeFromBasket} className="remove-button" style={styles.removeButton}>
          Remove from Invoice
        </Button>
      </div>

      
    </div>
  );
};

export default CheckoutItem;
