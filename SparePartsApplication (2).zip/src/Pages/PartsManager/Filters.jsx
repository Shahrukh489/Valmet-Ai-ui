import React, { useState, useEffect } from "react";
import Form from "react-bootstrap/Form";
import { Row, Col, Button } from "react-bootstrap";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import StickyNote2Icon from "@mui/icons-material/StickyNote2";
import { EmptySpareParts } from "./ExcelTemplates/EmptySpareParts"; // Adjust the path as necessary
import { Category } from "@mui/icons-material";

function Filters(props) {
  const [partNumber, setPartNumber] = useState("");
  const [location, setLocation] = useState("");
  const [category, setCategory]= useState("");
  const [status, setStatus] = useState("");
  const [chapters, setChapters] = useState([]);
  const [filteredParts, setFilteredParts] = useState([]);
  const [filteredPages, setFilteredPages] = useState([]);

  
  const [isLoading, setIsLoading] = useState(false);

  const SPAREPARTSAPI_BASE_URL =
    "https://wea-spt-use-dv-sparepartsapi-001.azurewebsites.net";

  const handleDownload = () => {
    const url = `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/generate-template`; // Update this URL as needed
    const fileName = "SparePartsListTemplate.xlsx";
    EmptySpareParts(url, fileName);
  };

  useEffect(() => {
    const fetchOptions = async () => {
      setIsLoading(true);

      try {
        const response = await fetch(
          `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetAllCategories`
        );
        const chapter = await response.json();
        setChapters(chapter.result);
      } catch (e) {
        //setError(e)
      } finally {
        setIsLoading(false);
      }
    };
    fetchOptions();
  }, []);

  
  const handleFilter = async () => {
    try {
      const queryParams = new URLSearchParams();
      // Conditionally append parameters if they have values
      if (partNumber) queryParams.append("PartNumber", partNumber);
      if (location) queryParams.append("Location", location);
      if (category) queryParams.append("Category", category);
      if (status) queryParams.append("Status", status);

      const url = `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetFilteredParts?${queryParams.toString()}`;
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();
      setFilteredParts(Array.isArray(data.result) ? data.result : []);
      setFilteredPages(data.pages) // Ensure data is always an array
      props.onFilteredParts(Array.isArray(data.result) ? data.result : []); // Pass data.result up to the parent component
      console.log(data.result);
    } catch (error) {
      console.error("Error fetching filtered data:", error);
    }
  };

  return (
    <div className="mb-4">
      <Row className="align-items-center">
        <Col xs={12} md={8} className="d-flex align-items-center">
          <Form.Control
            type="text"
            placeholder="Enter Part#"
            size="sm"
            style={{ height: "38px", marginRight: "10px" }}
            value={partNumber}
            onChange={(e) => setPartNumber(e.target.value)}
          />
          <Form.Select
            aria-label="Location"
            size="sm"
            style={{ height: "38px", marginRight: "10px" }}
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          >
            <option value="">Select Location</option>
            <option value="Houston">Houston</option>
            <option value="Finland">Finland</option>
          </Form.Select>
          <Form.Select
            aria-label="Category"
            size="sm"
            style={{ height: "38px", marginRight: "10px" }}
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option disabled value="">Category</option>
            {chapters.map((option) => {
              return (
                <option
                  key={option.itemKey}
                  value={option.itemKey}
                  style={{ fontSize: "13px" }}
                >
                  {option}
                </option>
              );
            })}
          </Form.Select>
          <Form.Select
            aria-label="Status"
            size="sm"
            style={{ height: "38px" }}
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">Select Status</option>
            <option value="All">All</option>
            <option value="One">One</option>
            <option value="Two">Two</option>
            <option value="Three">Three</option>
          </Form.Select>
        </Col>

        <Col
          xs={12}
          md={4}
          className="d-flex align-items-center justify-content-start mt-2 mt-md-0"
        >
          <Button
            variant="secondary"
            size="sm"
            style={{
              display: "flex",
              alignItems: "center",
              height: "38px",
              marginRight: "10px",
            }}
          >
            <FileUploadIcon style={{ marginRight: "5px" }} />
            Export
          </Button>

          <Button
            variant="secondary"
            size="sm"
            style={{
              display: "flex",
              alignItems: "center",
              height: "38px",
            }}
            onClick={handleFilter}
          >
            <StickyNote2Icon style={{ marginRight: "5px" }} />
            Apply Filters
          </Button>

          <Button
            variant="secondary"
            size="sm"
            style={{
              display: "flex",
              alignItems: "center",
              height: "38px",
              marginLeft: "10px",
            }}
            onClick={handleDownload}
          >
            <FileUploadIcon style={{ marginRight: "5px" }} />
            Generate Template
          </Button>
        </Col>
      </Row>
    </div>
  );
}

export default Filters;
