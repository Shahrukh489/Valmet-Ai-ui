import React from "react";
import PortalSidebar from "./PortalSidebar";
import { Outlet } from "react-router-dom";

function ManagerPortalMain() {
  return (
    <div className="app" style={{ display: "flex" }}>
      <PortalSidebar />
      <div
        style={{
          marginLeft: "250px", // ✅ same as sidebar width
          marginTop: "90px", // ✅ same as navbar height
          padding: "20px",
          width: "100%",
          boxSizing: "border-box",
        }}
      >
        <main>
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export default ManagerPortalMain;
