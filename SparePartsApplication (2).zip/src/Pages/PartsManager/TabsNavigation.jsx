import React from 'react'
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";

import PartsManager from './PartsManager';
import { Update } from '@mui/icons-material';
import UpdatePrice from './PartsPortalTabs/UpdatePrice';
import UpdateItem from './PartsPortalTabs/UpdateItem';
import SparePartsExcelInput from './SidebarPages/SparePartsExcelInput';

function TabsNavigation() {
  return (
    <div className="content">
      <Tabs
        defaultActiveKey="home"
        id="uncontrolled-tab-example"
        className="mb-4"
      >
        <Tab eventKey="home" title="Inventory">
          <PartsManager />
        </Tab>
        <Tab eventKey="profile" title="Add New Parts">
          <SparePartsExcelInput />
        </Tab>
        <Tab eventKey="updateitem" title="Update Item">
          <UpdateItem />
        </Tab>
        <Tab eventKey="contact" title="Update Price">
          <UpdatePrice />
        </Tab>
        <Tab eventKey="upload" title="Upload Wizard">
          Bulk Uploads
        </Tab>
      </Tabs>
    </div>
  );
}

export default TabsNavigation