import React from "react";
import { Link } from "react-router-dom";
import { BarChart, Box, Bug, FileText, UserCog } from "lucide-react";

const iconMap = {
  Analytics: <BarChart size={18} className="mr-2 inline-block" />,
  "Parts Portal": <Box size={18} className="mr-2 inline-block" />,
  "Role Manager": <UserCog size={18} className="mr-2 inline-block" />,
  "Generate Reports": <FileText size={18} className="mr-2 inline-block" />,
  "Reported Bugs": <Bug size={18} className="mr-2 inline-block" />,
};

const PortalSidebar = () => {
  return (
    <div
      style={{
        position: "fixed",
        top: "90px",
        left: 0,
        width: "250px",
        height: "calc(100vh - 90px)",
        overflowY: "auto",
        backgroundColor: "#1e1e2f",
        padding: "20px",
        zIndex: 1040,
      }}
    >
      <nav>
        <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
          {[
            { to: "/managerportal/analytics-page", label: "Analytics" },
            { to: "/managerportal", label: "Parts Portal" },
            { to: "/managerportal/role-manager", label: "Role Manager" },
            {
              to: "/managerportal/generate-reports",
              label: "Generate Reports",
            },
            { to: "/managerportal/bug-reports", label: "Reported Bugs" },
          ].map((item) => (
            <li key={item.to} style={{ marginBottom: "16px" }}>
              <Link
                to={item.to}
                style={{
                  color: "#fff",
                  textDecoration: "none",
                  fontSize: "16px",
                  display: "flex",
                  alignItems: "center",
                  padding: "8px 12px",
                  borderRadius: "4px",
                  transition: "background 0.2s ease-in-out",
                }}
                onMouseEnter={(e) =>
                  (e.target.style.backgroundColor = "#2e2e42")
                }
                onMouseLeave={(e) =>
                  (e.target.style.backgroundColor = "transparent")
                }
              >
                {iconMap[item.label]} <span>{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};

export default PortalSidebar;
