import React from 'react'

import { Container, Row } from "react-bootstrap";
import ReportPage from "./ReportPage";

function GenerateReports() {
  return (
    <div>
      {" "}
      <Container fluid>
        <header className="content">
          <h4>Generate Reports</h4>
          <p style={{ fontSize: "11px" }}>
            Generate reports for various aspects of the system. You can
            customize the report parameters and download them in different
            formats.
          </p>
        </header>
        <Row>
          <ReportPage />
        </Row>
      </Container>
    </div>
  );
}

export default GenerateReports