import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  TrendingUp,
  PackageCheck,
  DollarSign,
  PieChart as PieIcon,
} from "lucide-react";


const AnalyticsDashboard = () => {
  const totalSales = 12540;
  const totalOrders = 320;
  const totalRevenue = 25000;

  const topSellingParts = [
    { name: "Screwdriver Bit", sales: 75 },
    { name: "Torque Wrench", sales: 60 },
    { name: "Drill Bit", sales: 50 },
    { name: "Hex Key Set", sales: 40 },
  ];

const salesTrend = [
  { date: "Mar 1", revenue: 1200 },
  { date: "Mar 2", revenue: 1500 },
  { date: "Mar 3", revenue: 1700 },
  { date: "Mar 4", revenue: 1100 },
  { date: "Mar 5", revenue: 1900 },
];
  const categoryDistribution = [
    { category: "Tools", value: 40 },
    { category: "Fasteners", value: 30 },
    { category: "Machinery", value: 20 },
    { category: "Electrical", value: 10 },
  ];

  const pastInvoices = [
    { id: "INV-1001", customer: "Acme Corp", amount: 1280, date: "2024-04-01" },
    {
      id: "INV-1002",
      customer: "Tech Solutions",
      amount: 940,
      date: "2024-04-02",
    },
    { id: "INV-1003", customer: "BuildCo", amount: 1875, date: "2024-04-03" },
    { id: "INV-1004", customer: "MechWorks", amount: 1620, date: "2024-04-04" },
    {
      id: "INV-1005",
      customer: "NextGen Tools",
      amount: 1430,
      date: "2024-04-05",
    },
  ];

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042"];

  

  return (
    <div className="min-h-screen p-6 grid gap-6 font-sans text-slate-800">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-medium">Total Sales</h2>
              <TrendingUp size={20} className="text-green-600" />
            </div>
            <p className="text-3xl font-bold mt-1">${totalSales}</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-medium">Total Quotations</h2>
              <PackageCheck size={20} className="text-blue-600" />
            </div>
            <p className="text-3xl font-bold mt-1">{totalOrders}</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-medium">Total Revenue</h2>
              <DollarSign size={20} className="text-emerald-600" />
            </div>
            <p className="text-3xl font-bold mt-1">${totalRevenue}</p>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-medium">Category Distribution</h2>
              <PieIcon size={20} className="text-purple-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              As of April 5, 2024
            </p>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={categoryDistribution}
                  dataKey="value"
                  nameKey="category"
                  cx="50%"
                  cy="50%"
                  outerRadius={60}
                  label
                >
                  {categoryDistribution.map((entry, index) => (
                    <Cell key={index} fill={COLORS[index]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Analytics + Top Selling Parts side by side */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="shadow-lg">
          <CardContent className="p-4">
            <h2 className="text-lg font-semibold mb-4">
              Sales Trend (Last 5 Days)
            </h2>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={salesTrend}>
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#8884d8"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="shadow-lg">
          <CardContent className="p-4">
            <h2 className="text-lg font-semibold mb-4">Top Selling Parts</h2>
            <div className="space-y-2">
              {topSellingParts.map((part, idx) => (
                <div
                  key={idx}
                  className="flex justify-between border-b pb-2 text-sm"
                >
                  <span className="font-medium">{part.name}</span>
                  <span className="text-right text-muted-foreground">
                    {part.sales} units
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Past Invoices */}
      <Card className="shadow-lg">
        <CardContent className="p-4">
          <h2 className="text-lg font-semibold mb-4">Past Quotes</h2>
          <div className="space-y-3 max-h-[200px] overflow-y-auto pr-2">
            {pastInvoices.map((inv) => (
              <div
                key={inv.id}
                className="flex items-center justify-between border-b pb-2 text-sm"
              >
                <div>
                  <div className="font-medium">{inv.id}</div>
                  <div className="text-xs text-muted-foreground">
                    {inv.customer} • {inv.date}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="font-semibold">${inv.amount}</div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="bg-yellow-400 hover:bg-yellow-500 text-black border-yellow-500"
                  >
                    View
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AnalyticsDashboard;
