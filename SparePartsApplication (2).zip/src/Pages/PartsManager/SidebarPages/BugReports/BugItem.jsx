import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { Button } from "react-bootstrap";
import { ListGroup } from "react-bootstrap";
import { Link } from "react-router-dom";

const BugItem = (props) => {
  return (
    <Container>
 
        <ListGroup as="ol" className="ms-0">
          <ListGroup.Item
            className="d-flex align-items-center"
            style={{ borderRadius: "3px", width: "1500px" }}
          >
            <Col md={2} style={{ marginTop: "10px" }}>
                <p style={{fontSize: "12px "}}>ID: </p>
            </Col>

            <Col
              md={7}
              style={{ textAlign: "left", overflow: "auto" }}
            >
              <div>
                <h6>{props.name}</h6>
                <p style={{ fontSize: "12px" }}>
                  {/* Part Number: {props.partNumber} */}
                </p>

                {/* {props.kit === "Yes" ? (
                              <p style={{ fontSize: "12px" }}>
                                isKit:{" "}
                                <Link
                                  to={`/itemdetails/${props.name}/${props.partNumber}`}
                                  style={{ color: "blue" }}
                                >
                                  See Items In Kit
                                </Link>
                              </p>
                            ) : (
                              <p style={{ fontSize: "12px" }}>isKit: {props.kit}</p>
                            )} */}

                <p
                  style={{
                    maxHeight: "150px",
                    overflow: "auto",
                    fontSize: "12px",
                    textAlign: "left",
                    marginLeft: "0px",
                  }}
                  className=" pt-0"
                >
                  Description: {props.name}
                </p>
              </div>
            </Col>

            <Col
              xs={12}
              md={1}
              style={{ fontSize: "12px" }}
              className="p-1 mt-3"
            >
              <Link to={"/details"}>See Details</Link>
              {/* <p>{USDollar.format(props.price)}</p> */}
            </Col>

            <Col
              style={{
                height: "40px",
                justifyContent: "flex-end",
              }}
              xs={12}
              md={2}
            >
            </Col>
          </ListGroup.Item>
        </ListGroup>
    </Container>
  );
};

export default BugItem;
