import { useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Bug } from "lucide-react";

const statusOptions = ["Reported", "In Progress", "Resolved"];

const ReportedBugs = () => {
  const [query, setQuery] = useState("");
  const [bugs, setBugs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null); // track which card is being edited

  const filteredBugs = bugs.filter((bug) =>
    bug.id?.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    const fetchBugs = async () => {
      try {
        const res = await fetch(
          "https://wea-spt-use-dv-pricingapi-001.azurewebsites.net/getAllBugsReported"
        );

        if (!res.ok) {
          console.error("HTTP error:", res.status);
          return;
        }

        const text = await res.text();
        if (!text) return;

        const data = JSON.parse(text);

        if (data.isSuccess && Array.isArray(data.result)) {
          setBugs(data.result);
        } else {
          console.error("API error:", data.message || "Unexpected structure");
        }
      } catch (error) {
        console.error("Fetch error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBugs();
  }, []);

  const handleStatusChange = (bugId, newStatus) => {
    setBugs((prev) =>
      prev.map((bug) =>
        bug.id === bugId ? { ...bug, status: newStatus } : bug
      )
    );
    setEditingId(null);

    // Optional API call to persist status
    // await fetch('/v1/pricing/updateBugStatus', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ id: bugId, status: newStatus }),
    // });
  };

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold flex items-center gap-2">
          <Bug className="text-red-500" /> Reported Bugs
        </h1>
        <Input
          placeholder="Search by Bug ID..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="max-w-sm"
        />
      </div>

      {loading ? (
        <p className="text-center text-muted-foreground">Loading bugs...</p>
      ) : (
        <ScrollArea className="h-[calc(100vh-200px)]">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredBugs.map((bug) => (
              <Card
                key={bug.id}
                className="shadow-sm cursor-pointer"
                onClick={() => setEditingId(bug.id)}
              >
                <CardContent className="p-4 space-y-2">
                  <h3 className="font-semibold text-lg">{bug.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {bug.description}
                  </p>
                  <div className="text-sm">
                    <strong>ID:</strong> {bug.id}
                  </div>
                  <div className="text-sm">
                    <strong>Severity:</strong> {bug.severity}
                  </div>
                  <div className="text-sm">
                    <strong>Reported By:</strong> {bug.reportedBy}
                  </div>
                  <div className="text-sm">
                    <strong>Date:</strong>{" "}
                    {new Date(bug.dateReported).toLocaleDateString()}
                  </div>
                  <div className="text-sm flex flex-col">
                    <strong>Status:</strong>
                    {editingId === bug.id ? (
                      <select
                        autoFocus
                        value={bug.status}
                        onChange={(e) =>
                          handleStatusChange(bug.id, e.target.value)
                        }
                        onBlur={() => setEditingId(null)}
                        className="mt-1 border rounded px-2 py-1 text-sm"
                      >
                        {statusOptions.map((status) => (
                          <option key={status} value={status}>
                            {status}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <span
                        className={
                          bug.status === "Resolved"
                            ? "text-green-600 font-medium"
                            : bug.status === "In Progress"
                            ? "text-yellow-600 font-medium"
                            : "text-red-600 font-medium"
                        }
                      >
                        {bug.status}
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
};

export default ReportedBugs;
