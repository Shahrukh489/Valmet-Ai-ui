import React from "react";

import { Container } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import PersonSearchIcon from "@mui/icons-material/PersonSearchRounded";
import BugReportIcon from "@mui/icons-material/BugReport";

function SearchBug() {
  return (
    <div className="mb-3 d-flex" style={{ width: "300px" }}>
      <BugReportIcon color="secondary"/>
      <Form.Control size="sm" type="text" placeholder="ID: 12345-78" />
    </div>
  );
}

export default SearchBug;
