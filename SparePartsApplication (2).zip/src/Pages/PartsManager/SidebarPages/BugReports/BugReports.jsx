import React from 'react'

import { Container, Row } from 'react-bootstrap';
import BugReportsInterface from './BugReportsInterface';

const BugReports = () => {
  return (
      <Container fluid>
            <BugReportsInterface />    
      </Container>
    
  );
}

export default BugReports