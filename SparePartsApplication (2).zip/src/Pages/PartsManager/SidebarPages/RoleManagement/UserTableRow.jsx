import React, { useState, useEffect } from "react";
import { Button, Spinner } from "react-bootstrap";

function UserTableRow({ item, handleEditRoleClick }) {
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchRoles = async () => {
      try {
        const response = await fetch(
          "https://wea-spt-use-dv-authenticationapi-001.azurewebsites.net/api/auth/GetUserRoleID",
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ userID: item.id }),
          }
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const rolesData = await response.json();
        setRoles(rolesData.result);
      } catch (err) {
        setError(err.message);
        setRoles([]);
      } finally {
        setLoading(false);
      }
    };

    fetchRoles();
  }, [item.id]);

  return (
    <tr>
      <td>{item.name}</td>
      <td>{item.email}</td>
      <td>
        {loading && <Spinner animation="border" size="sm" />}
        {error && <span className="text-danger">Error loading roles</span>}
        {!loading &&
          !error &&
          (roles.length ? roles.join(", ") : "Not Assigned")}
      </td>
      <td>
        <Button
          size="sm"
          variant="warning"
          onClick={() => handleEditRoleClick(item)}
        >
          Edit Role
        </Button>
      </td>
    </tr>
  );
}

export default UserTableRow;
