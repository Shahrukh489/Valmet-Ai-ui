import React, { useState, useEffect } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import {
  Button,
  Form,
  Table,
  Spinner,
  Card,
  InputGroup,
  Modal,
} from "react-bootstrap";

import UserTable from "./UserTable"; // Assuming you have this component

function RoleManagerInterface() {
  const [roles, setRoles] = useState([]);
  const [newRole, setNewRole] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showModal, setShowModal] = useState(false); // Modal state
  const [isConfirming, setIsConfirming] = useState(false); // Confirmation flag

  const AuthApiBaseUrl = import.meta.env.VITE_AUTHENTICATIONAPI_BASE_URL;

  // Fetch roles from API
  useEffect(() => {
    const fetchRoles = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(
          `${AuthApiBaseUrl}/api/auth/GetAllRoles`
        ); // Replace with your actual API endpoint
        const data = await response.json();
        if (data.isSuccess && data.result) {
          setRoles(data.result); // Accessing the roles array from `result`
        }
      } catch (error) {
        console.error("Error fetching roles:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRoles();
  }, []);

  const handleAddRole = () => {
    setShowModal(true); // Show confirmation modal
  };

  const confirmAddRole = async () => {
    setIsConfirming(true);
    try {
      // Assuming your API accepts POST requests to add new roles
      const response = await fetch(`${AuthApiBaseUrl}/api/auth/CreateRole`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newRole }),
      });
      if (response.ok) {
        const addedRole = await response.json();
        if (addedRole.isSuccess) {
          setRoles([...roles, addedRole.result]);
          setNewRole("");
        }
      } else {
        console.error("Failed to add role");
      }
    } catch (error) {
      console.error("Error adding role:", error);
    } finally {
      setIsConfirming(false);
      setShowModal(false);
    }
  };

  return (
    <div className="content">
      <Tabs
        defaultActiveKey="home"
        id="uncontrolled-tab-example"
        className="mb-4"
      >
        <Tab eventKey="home" title="Users">
          <UserTable />
        </Tab>

        {/* Add Roles Tab */}
        <Tab eventKey="addrole" title="Add Roles">
          <div className="mb-4">
            {/* Add Role Form */}
            <Card className="shadow-sm p-4">
              <Card.Body>
                <h5>Add New Role</h5>
                <Form>
                  <Form.Group controlId="roleName">
                    <Form.Label>Role Name</Form.Label>
                    <InputGroup>
                      <Form.Control
                        type="text"
                        value={newRole}
                        onChange={(e) => setNewRole(e.target.value)}
                        placeholder="Enter new role name"
                        className="rounded-3"
                      />
                    </InputGroup>
                  </Form.Group>

                  {/* Add Role Button */}
                  <Button
                    variant="primary"
                    onClick={handleAddRole}
                    disabled={isLoading || !newRole.trim()}
                    className="w-100 py-2 mt-3 rounded-3 fw-semibold"
                    style={{ fontSize: "14px", textTransform: "uppercase" }}
                  >
                    {isLoading ? "Adding..." : "Add Role"}
                  </Button>
                </Form>
              </Card.Body>
            </Card>
          </div>

          {/* Existing Roles Table */}
          {isLoading ? (
            <div className="text-center py-5">
              <Spinner animation="border" variant="primary" />
              <p className="mt-2">Loading roles...</p>
            </div>
          ) : (
            <Card className="mt-4 shadow-sm">
              <Card.Body>
                <h5>Existing Roles</h5>
                <Table responsive striped bordered hover size="sm">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Role Name</th>
                    </tr>
                  </thead>
                  <tbody>
                    {roles.length > 0 ? (
                      roles.map((role, index) => (
                        <tr key={index}>
                          <td>{index + 1}</td>
                          <td>{role}</td>{" "}
                          {/* Since roles are just strings now */}
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan="2" className="text-center">
                          No roles available.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </Table>
              </Card.Body>
            </Card>
          )}
        </Tab>
      </Tabs>

      {/* Confirmation Modal */}
      <Modal
        show={showModal}
        onHide={() => setShowModal(false)}
        centered // Bootstrap 5 utility class to center the modal vertically
        size="lg" // Adjust size if needed
      >
        <Modal.Header closeButton>
          <Modal.Title>Confirm Add Role</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to add the role "{newRole}"?
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={confirmAddRole}
            disabled={isConfirming}
          >
            {isConfirming ? "Adding..." : "Confirm"}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default RoleManagerInterface;
