import React, { useState } from 'react'

import { Container, Row } from 'react-bootstrap';

import RoleManagerInterface from './RoleManagerInterface';

function RoleManager() {

  const [setUserList, UserList] = useState([])
  const [isLoading, setIsLoading] = useState(false);

  
  return (
    <Container fluid>
      <header className="content">
        <h4>Role Manager</h4>
        <p style={{ fontSize: "11px" }}>
          Edit, Update, Delete Roles for users of the parts management application
        </p>
      </header>
      <Row>
       <RoleManagerInterface />
      </Row>
    </Container>
  );
}

export default RoleManager