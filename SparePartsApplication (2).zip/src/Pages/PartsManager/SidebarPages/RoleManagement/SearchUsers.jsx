import React from 'react'

import { Container } from 'react-bootstrap'
import Form from "react-bootstrap/Form";
import PersonSearchIcon from "@mui/icons-material/PersonSearchRounded";

function SearchUsers() {
  return (
    <div className='mb-3 d-flex' style={{width: '300px'}}>
      <PersonSearchIcon  color='success'/><Form.Control size="sm" type="text" placeholder="example@valmet.com" />   
    </div>
  );
}

export default SearchUsers