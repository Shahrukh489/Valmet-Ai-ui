import React, { useState, useEffect } from "react";
import { Table, Button, Modal, Form, Spinner, Alert } from "react-bootstrap";
import UserTableRow from "./UserTableRow";
import SearchUsers from "./SearchUsers";

function UserTable() {
  const [userList, setUserList] = useState([]);
  const [roles, setRoles] = useState([]); // For storing roles
  const [showModal, setShowModal] = useState(false); // To control modal visibility
  const [selectedRole, setSelectedRole] = useState(""); // The selected role from the dropdown
  const [selectedUser, setSelectedUser] = useState(null); // The user whose role will be edited
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null); // To handle any errors

  const AuthApiBaseUrl = import.meta.env.VITE_AUTHENTICATIONAPI_BASE_URL;

  // Fetch users and roles when the component mounts
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);

        // Fetch Users
        const userResponse = await fetch(
          `${AuthApiBaseUrl}/api/auth/GetAllUsers`
        );
        if (!userResponse.ok) {
          throw new Error("Failed to fetch users");
        }
        const users = await userResponse.json(); // Parse response as JSON
        setUserList(users.result || []); // Ensure users.result exists

        // Fetch Roles
        const response = await fetch(
          `${AuthApiBaseUrl}/api/auth/GetAllRoles`
        ); // Replace with your actual API endpoint
        const data = await response.json();
        if (data.isSuccess && data.result) {
          setRoles(data.result); // Accessing the roles array from `result`
        }
      } catch (error) {
        console.error("Error fetching roles:", error);
      } finally {
        setIsLoading(false);
      }
   
    };

    fetchData();
  }, []);

  // Handle the "Edit Role" button click
  const handleEditRoleClick = (user) => {
    setSelectedUser(user); // Set the selected user
    setSelectedRole(user.role || ""); // Pre-select the current role
    setShowModal(true); // Show the modal
  };

  // Handle role update
  const handleConfirmRoleChange = async () => {
    if (!selectedRole) {
      alert("Please select a role.");
      return;
    }

    try {
      // Make an API call to update the role (Replace with your actual API)
      const response = await fetch(`${AuthApiBaseUrl}/api/auth/update-role`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: selectedUser.email, // Assuming each user has an `id`
          newRole: selectedRole,
        }),
      });

      if (response.ok) {
        const updatedUser = await response.json();
        alert(`Role updated successfully for ${updatedUser.name}`);
        // Optionally, refresh the user list after update
        const updatedUserList = userList.map((user) =>
          user.id === updatedUser.id ? updatedUser : user
        );
        setUserList(updatedUserList);
      } else {
        alert("Failed to update role.");
      }
    } catch (error) {
      console.error("Error updating role:", error);
    } finally {
      setShowModal(false); // Close the modal
    }
  };

  return (
    <div>
      <SearchUsers />

      {/* Show error alert if there was an issue fetching data */}
      {error && <Alert variant="danger">{error}</Alert>}

      <Table striped hover bordered>
        <thead style={{ fontSize: "13px" }}>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Permissions</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {isLoading ? (
            <tr>
              <td colSpan="4" className="text-center">
                <Spinner animation="border" variant="primary" />
                <p>Loading...</p>
              </td>
            </tr>
          ) : (
            userList.map((user, index) => (
              <UserTableRow
                key={index}
                item={user}
                handleEditRoleClick={handleEditRoleClick}
              />
            ))
          )}
        </tbody>
      </Table>

      {/* Modal to edit role */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Role for {selectedUser?.name}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="roleSelect">
              <Form.Label>Select Role</Form.Label>
              <Form.Control
                as="select"
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value)}
              >
                <option value="">-- Select Role --</option>
                {roles.length > 0 ? (
                  roles.map((role, index) => (
                    <option key={index} value={role}>
                      {role}
                    </option>
                  ))
                ) : (
                  <option value="">No roles available</option>
                )}
              </Form.Control>
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancel
          </Button>
          <Button
            variant="primary"
            onClick={handleConfirmRoleChange}
            disabled={isLoading || !selectedRole}
          >
            {isLoading ? "Updating..." : "Confirm Role"}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default UserTable;
