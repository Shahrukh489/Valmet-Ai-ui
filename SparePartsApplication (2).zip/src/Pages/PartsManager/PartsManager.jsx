import Table from "react-bootstrap/Table";
import React, { useState, useEffect } from "react";
import { Col, Row, Spinner } from "react-bootstrap";

import "./PartsManager.css";
import TableRow from "./TableRow"
import Filters from "./Filters";

function PartsManager() {
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [isLoading, setIsLoading] = useState(false);
    const [partsData, setPartsData] = useState([]);
    const [filtersApplied, setFiltersApplied] = useState(false);


    const [partsList, setPartsList] = useState([]);

    //URLS
    const SPAREPARTSAPI_BASE_URL =
      "https://wea-spt-use-dv-sparepartsapi-001.azurewebsites.net";

    const handleFilteredParts = (data) => {
      console.log(data);
      setPartsData(Array.isArray(data) ? data : []); // Ensure data is always an array
      setFiltersApplied(true); // Indicate that filters have been applied
    };

     const fetchParts = async () => {
       setIsLoading(true);
       try {
         const response = await fetch(
           `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetSpareParts?pageNumber=${currentPage}&pageSize=15`
         );
         const parts = await response.json();
         setPartsList(parts.result.data);
         setTotalPages(parts.result.totalPages);
       } catch (error) {
         console.error("Error fetching spare parts:", error);
       } finally {
         setIsLoading(false);
       }
     };

     useEffect(() => {
       fetchParts();
     }, [currentPage]);

  return (
    <div>
      <Filters onFilteredParts={handleFilteredParts} />
      <main style={{ maxHeight: "442px", overflow: "auto" }}>
        <Table
          striped
          hover
          bordered
          style={{
            fontSize: "12px",
            textAlign: "center",
          }}
        >
          <thead style={{ fontSize: "13px" }}>
            <tr>
              <th>Part No</th>
              <th>Image</th>
              <th>Description</th>
              <th>Price</th>
              <th>VED</th>
              <th>Anton Staus</th>
              <th>Maxum</th>
              <th>MLFB</th>
              <th>Category</th>
              <th>Pricebook Category</th>
              <th>Note</th>
              <th>Internal Note</th>
              <th>Sales Text</th>
              <th>min WH</th>
            </tr>
          </thead>

          <tbody>
            {partsData.length === 0
              ? partsList.map((item, index) => (
                  // <CheckoutItem
                  //   key={item.id}
                  //   name={item.name}
                  //   partNumber={item.partNumber}
                  //   image={item.image}
                  //   description={item.description}
                  //   price={item.price}
                  // />
                  <TableRow key={index} item={item} />
                ))
              : 
                Array.isArray(partsData) && partsData.map((part, index) => (
                  <TableRow key={index} item={part} />
              ))
             }
          </tbody>
        </Table>
      </main>
    </div>
  );
}

export default PartsManager