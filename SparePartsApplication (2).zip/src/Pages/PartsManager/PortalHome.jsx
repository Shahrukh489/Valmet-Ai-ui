import React from 'react'

import { Container, Row, Col } from 'react-bootstrap';
import TabsNavigation from './TabsNavigation';

function PortalHome() {
  return (
    <Container fluid>
      <header className="content">
        <h4>Parts Management Portal</h4>
        <p style={{ fontSize: "11px" }}>
          Edit, Update, Delete Parts information existing in the current
          database and also perform master data updates by importing data
        </p>
      </header>
      <Row>
        <TabsNavigation />
      </Row>
    </Container>
  );
}

export default PortalHome