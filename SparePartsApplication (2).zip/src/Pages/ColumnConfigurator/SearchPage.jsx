import Container from "react-bootstrap/Container";
import SearchBar from "../../components/SearchBarComp/SearchBar";
import { useState } from "react";
import { Col, Row, Button, Modal } from "react-bootstrap";

import DefaultGridView from "./DefaultGridView";
import SearchListViewPage from "./SearchListViewPage";

import Filterbox from "../../components/FilterBox/Filterbox";
import MLFB from "../../components/MLFB/MLFB";
import Possibilities from "../../components/FilterBox/Possibilities";

function SearchPage() {
  const [searchFilter, setSearchFilter] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [displayGrid, setDisplayGrid] = useState(false);

  const [MLFBArray, setMLFBArray] = useState([]);
  const [options, setOptions] = useState([]);
  const [parsedConfiguration, setParsedConfiguration] = useState([]);
   const [showNotFoundModal, setShowNotFoundModal] = useState(false);
   const [totalItems, setTotalItems] = useState(0);


  const [partNumberOptions, setPartNumberOptions] = useState([]);
  const [partNumber, setPartNumber] = useState("");
  const [searchByCOL, setSearchByCOL] = useState(false);

  const [generateConfiguration, setGenerateConfiguration] = useState([]);
  const [price, setPrice] = useState();

  const newArr = []

  function getData(data) {
    console.log(data);
    setSearchFilter(data);
    setSearchByCOL(true)
  }

  function getColumnNumberOptions(data) {
    console.log(data);
    //if does not = [] -> then show modal error
    if(data.length > 0)
    {
      setPartNumberOptions(data);
    }
    else
    {
      setShowNotFoundModal(true);
    }
  }

  const handleSetList = () => {
    setDisplayGrid(false);
  };

  const handleSetGrid = () => {
    setDisplayGrid(true);
  };

  function getParsedInformation(data) {
    console.log(data);
    setParsedConfiguration(data);
    console.log(parsedConfiguration);
  }

  function getConfigurations(data) {
    console.log(data);
  }

  function handleFinalConfiguration(data) {
    console.log(data);

    const newArr = ([...data, ...partNumberOptions])

    if (partNumberOptions.length > 0) {
      console.log('here');
      generatePartNumber(partNumberOptions);
    }else
    {

      console.log('in else');
      data.shift()
      data.shift()
      data.shift()
      console.log(data);
      generatePartNumber(data);
     
    }

    setMLFBArray([])
    newArr.forEach(option => {
      setMLFBArray(oldArray => [...oldArray, option.code])
      console.log(MLFBArray);
    })
    setGenerateConfiguration(newArr);
    generatePricing(newArr);
    
  }

  async function generatePartNumber(partNumberOptions) {

    try {
      const response = await fetch(
        "https://wea-spt-use-dv-configurationsapi-001.azurewebsites.net/v1/configurations/generatePartNumber",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(partNumberOptions),
        }
      )
        .then((response) => response.json())
        .then((parsedJSON) => setPartNumber(parsedJSON.result));
    } catch (e) {
      //setError(e)
    } finally {
      setIsLoading(false)
    }
  }


  async function generatePricing(options) {
    try {
      const response = await fetch(
        "https://wea-spt-use-dv-pricingapi-001.azurewebsites.net/packedColumnPricing",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ options }),
        }
      )
        .then((response) => response.json())
        .then((parsedJSON) => setPrice(parsedJSON.result));
    } catch (e) {
      //setError(e)
    } finally {
      setIsLoading(false);
    }
  }
  return (
    <div style={{ paddingTop: "90px" }}>
      <Row className="p-5">
        <Col xs={11} className="p-0">
          <Row>
            <Col xs={9} md={12} style={{ marginLeft: "32px" }}>
              <SearchBar
                getData={getData}
                getPreSetOptions={getColumnNumberOptions}
                placeholder="Search Part Number Ex: 'COL1044'"
              />
            </Col>
            <Col
              className="mt-5 p-4"
              style={{
                border: "1px solid #d2d4d2",
                marginLeft: "45px",
                maxHeight: "600px",
                maxWidth: "400px",
              }}
            >
              <Filterbox
                setMLFBArray={setMLFBArray}
                setOptions={setOptions}
                setConfiguration={getConfigurations}
                partNumberOptions={partNumberOptions}
                setPartNumberOptions={setPartNumberOptions}
                setGenerateConfiguration={handleFinalConfiguration}
              />
            </Col>

            <Col xs={8} className="mt-5" style={{ marginLeft: "45px" }}>
              <div>
                <div style={{ alignItems: "center" }}>
                  <div style={{}} className="align-items-center ">
                    <MLFB mlfbCode={MLFBArray} />
                  </div>
                </div>
                <br />

                <Possibilities
                  data={searchFilter}
                  selectedOptions={options}
                  setMLFBArray={setMLFBArray}
                  mlfbCode={MLFBArray}
                  finalConfig={generateConfiguration}
                  partNumber={partNumber}
                  price={price}
                />
              </div>

              {/* {displayGrid ? (
              <DefaultGridView search={searchFilter} />
            ) : (
              <SearchListViewPage search={searchFilter} />
            )} */}

              {/* <Col xs={12} md={4} className="p-0" style={{ marginLeft: "10px" }}>
            <Button variant="outline-primary" onClick={handleSetList}>
              <FormatListBulletedIcon />
            </Button>
            <Button
              style={{ marginLeft: "5px" }}
              variant="outline-primary"
              onClick={handleSetGrid}
            >
              <GridViewIcon />
            </Button>
           */}
            </Col>
          </Row>
        </Col>

        {/* Column Not Found Modal */}
        <Modal
          show={showNotFoundModal}
          onHide={() => setShowNotFoundModal(false)}
          centered
        >
          <Modal.Header closeButton>
            <Modal.Title>Column Was Not Found</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p className="text-danger">
              No column was found matching this COL number {searchFilter}.
            </p>
          </Modal.Body>
          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => setShowNotFoundModal(false)}
            >
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      </Row>
    </div>
  );
}

export default SearchPage;
