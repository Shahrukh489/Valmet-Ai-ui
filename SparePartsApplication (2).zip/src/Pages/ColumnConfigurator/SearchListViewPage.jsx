import React from "react";
import TableComp from "../../components/TableComp/TableComp";
import { Col, Row } from "react-bootstrap";

function SearchListViewPage(props) {
  return (
    <Row>
      <Col xs={12} >
        <TableComp search={props.search} />
      </Col>
    </Row>
  );
}

export default SearchListViewPage;
