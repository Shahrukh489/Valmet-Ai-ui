import React, { useEffect, useState } from "react";
import { Col, Row } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Accordian from "../../components/AccordionComp/Accordian";
import Spinner from 'react-bootstrap/Spinner';


function PartsBook() {
const [chapterTitles, setChapterTitles] = useState([])
const [isLoading, setIsLoading] = useState(false);

useEffect(() => {
  setIsLoading(true)
  const setChapters = async () => {
      try {
          const response = await fetch('http://localhost:5034/v1/spareparts/api/spareparts/GetChapters')
          var x = await response.json()
          console.log(x.result)
          setChapterTitles(x.result)
      } catch (e) {
          //setError(e)
      } finally {
          setIsLoading(false)
      }
  }
  setChapters();
}, []);

if (isLoading) {
  return (
      <Spinner animation="border" role="status" style={{ alignItems: 'center' }}>
          <span className="visually-hidden">Loading...</span>
      </Spinner>)
}

  return (
    <Row className="p-5">
      <Col xs={11} className="p-0 mt-5 mb-4">
        <Row>
          <Col xs={9} md={12} style={{ marginLeft: "45px" }}>
            {chapterTitles?.map((title)=> {
                return(
                  <Accordian chapterTitles={title.title} chapter={title.chapter} relation={title.itemKey}/>
                )
            })}
            
          </Col>
        </Row>
      </Col>
    </Row>
  );
}

export default PartsBook;
