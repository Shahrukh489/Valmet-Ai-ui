import React from "react";

import Container from "react-bootstrap/Container";
import { useStateValue } from "../../Redux/stateProvider";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import { useState } from "react";
import CardComp from "../../components/CardComponent/CardComp";

import data from "../../mock/temp_data.json";

function DefaultGridView(props) {
  const [{ basket }, dispatch] = useStateValue();

  return (
    <Row>
      {data
        .filter((val) => {
          if (props.search == "") {
            return val;
          } else if (
            val.item_name.toLowerCase().includes(props.search.toLowerCase())
          ) {
            return val;
          }
        })
        .map((val) => {
          return (
            <Col xs={12} sm={6} md={3}>
              <CardComp
                key={val.id}
                id={val.id}
                name={val.item_name}
                image={val.image}
                price={val.price}
              />
            </Col>
          );
        })}
    </Row>
  );
}

export default DefaultGridView;
