const Unauthorized = () => (
  <div className="text-center p-10 text-red-600 text-xl">
    🚫 You do not have permission to view this page.
  </div>
);

export default Unauthorized;
