

function NotFoundPage() {
  return (
    <div>
        <h1>404 Notfound</h1>
    </div>
  )
}

export default NotFoundPage