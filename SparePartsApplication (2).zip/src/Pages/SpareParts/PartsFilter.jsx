import React, { useState, useEffect } from "react";
import { Container, Col, Button, Form, Spinner, Card } from "react-bootstrap";
import {
  Command,
  CommandInput,
  CommandItem,
  CommandList,
  CommandEmpty,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import RestartAltIcon from "@mui/icons-material/RestartAlt";

function PartsFilter({ setFormData, getSearchValue, onSubmitFilter }) {
  const [itemCategories, setItemCategories] = useState([]);
  const [productCategories, setProductCategories] = useState([]);
  const [subProductCategories, setSubProductCategories] = useState([]);

  const [formDataLocal, setFormDataLocal] = useState({});
  const [gcTerm, setGcTerm] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [openField, setOpenField] = useState(null);

  const SPAREPARTSAPI_BASE_URL =
    "https://wea-spt-use-dv-sparepartsapi-001.azurewebsites.net";

  useEffect(() => {
    const fetchFilterOptions = async () => {
      try {
        const [itemRes, productRes, subProductRes] = await Promise.all([
          fetch(
            `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetAllItemCategories`
          ),
          fetch(
            `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetAllProductCategories`
          ),
          fetch(
            `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetAllSubProductCategories`
          ),
        ]);

        const [itemData, productData, subProductData] = await Promise.all([
          itemRes.json(),
          productRes.json(),
          subProductRes.json(),
        ]);

        setItemCategories(itemData.result || []);
        setProductCategories(productData.result || []);
        setSubProductCategories(subProductData.result || []);
      } catch (error) {
        console.error("Error fetching filter options:", error);
      }
    };

    fetchFilterOptions();
  }, []);

  const handleInputChange = (value, field) => {
    const updatedData = { ...formDataLocal, [field]: value };
    setFormDataLocal(updatedData);
    setFormData(updatedData);
  };

  const handleGCInput = (e) => {
    const term = e.target.value;
    setGcTerm(term);
    getSearchValue?.(term);
    handleInputChange(term, "mlfb");
  };

  const handleSearchInput = (e) => {
    const term = e.target.value;
    setSearchTerm(term);
    getSearchValue?.(term);
    handleInputChange(term, "description");
  };

  const handleReset = () => {
    const clearedData = {
      itemCategory: "",
      productCategory: "",
      subProductCategory: "",
      mlfb: "",
      description: "",
    };

    setFormDataLocal(clearedData);
    setFormData(clearedData);
    setGcTerm("");
    setSearchTerm("");
  };

  const Combobox = ({ options, value, field }) => (
    <Popover
      open={openField === field}
      onOpenChange={() => setOpenField(field)}
    >
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          size="sm"
          className="justify-between w-full mb-2 text-left border border-gray-300"
        >
          {value || `Select ${field}`}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0">
        <Command>
          <CommandInput placeholder="Search..." className="h-9" />
          <CommandEmpty>No match found.</CommandEmpty>
          <CommandList>
            {options.map((opt, idx) => {
              const val = typeof opt === "object" ? opt.itemKey : opt;
              return (
                <CommandItem
                  key={idx}
                  value={val}
                  className="text-left"
                  onSelect={() => {
                    handleInputChange(val, field);
                    setOpenField(null);
                  }}
                >
                  {val}
                </CommandItem>
              );
            })}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );

  return (
    <Card
      className="shadow-sm p-3 rounded"
      style={{ backgroundColor: "#f8f9fa" }}
    >
      <Form
        id="filter-form"
        onSubmit={(e) => {
          e.preventDefault();
          onSubmitFilter?.(formDataLocal, 1);
        }}
      >
        <div className="d-flex align-items-center mb-3">
          <h5 className="m-0 me-auto" style={{ fontWeight: 600 }}>
            Spare Parts Filter
          </h5>
          <Button
            type="button"
            variant="warning"
            size="sm"
            onClick={handleReset}
          >
            <RestartAltIcon style={{ fontSize: "16px" }} />
          </Button>
        </div>

        <Form.Group className="mb-3">
          <Form.Label className="fw-bold small">Search GC#</Form.Label>
          <Form.Control
            type="text"
            placeholder="e.g. P10..."
            size="sm"
            value={gcTerm}
            onChange={handleGCInput}
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label className="fw-bold small">Item Category</Form.Label>
          <Combobox
            options={itemCategories}
            value={formDataLocal.itemCategory}
            field="itemCategory"
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label className="fw-bold small">Product Category</Form.Label>
          <Combobox
            options={productCategories}
            value={formDataLocal.productCategory}
            field="productCategory"
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label className="fw-bold small">
            Sub Product Category
          </Form.Label>
          <Combobox
            options={subProductCategories}
            value={formDataLocal.subProductCategory}
            field="subProductCategory"
          />
        </Form.Group>

        <Form.Group className="mb-4">
          <Form.Label className="fw-bold small">Part Description</Form.Label>
          <Form.Control
            type="text"
            placeholder="Search descriptions..."
            size="sm"
            value={searchTerm}
            onChange={handleSearchInput}
          />
        </Form.Group>

        <div className="d-grid gap-2">
          <Button
            type="submit"
            variant="success"
            size="sm"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Spinner animation="border" size="sm" /> Searching...
              </>
            ) : (
              "Search Spare Parts"
            )}
          </Button>
        </div>
      </Form>
    </Card>
  );
}

export default PartsFilter;
