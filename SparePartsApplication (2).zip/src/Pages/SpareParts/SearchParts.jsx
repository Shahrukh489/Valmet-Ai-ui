import React, { useState, useEffect } from "react";
import { Col, Row, Spinner } from "react-bootstrap";
import MyPagination from "./MyPagination";
import PartsFilter from "./PartsFilter";
import SparePartListItem from "./SparePartListItem";
import SearchBar from "../../components/SearchBarComp/SearchBar";
import ListView from "./ListView";

function SearchParts() {
  const [isLoading, setIsLoading] = useState(false);
  const [partsList, setPartsList] = useState([]);
  const [filteredPartsList, setFilteredPartsList] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState([]);
  const [viewToggled, setViewToggled] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [currentFilteredPage, setCurrentFilteredPage] = useState(1);
  const [isFiltered, setIsFiltered] = useState(false);
  const [isGCSearch, setIsGCSearch] = useState(false);
  const [isFilterDropdownActive, setIsFilterDropdownActive] = useState(false);
  const [totalPages, setTotalPages] = useState(1);
  const [totalItems, setTotalItems] = useState(0);
  const [displayedParts, setDisplayedParts] = useState([]);
  const [activeSearchTerm, setActiveSearchTerm] = useState("");

  const SPAREPARTSAPI_BASE_URL =
    "https://wea-spt-use-dv-sparepartsapi-001.azurewebsites.net";

  const fetchParts = async (page = 1) => {
    setIsLoading(true);
    try {
      const response = await fetch(
        `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetSpareParts?pageNumber=${page}&pageSize=15`
      );
      const parts = await response.json();
      setPartsList(parts.result.data);
      setDisplayedParts(parts.result.data);
      setTotalPages(parts.result.totalPages);
      setTotalItems(parts.result.totalItems);
    } catch (error) {
      console.error("Error fetching spare parts:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFilterSubmitFromDropdown = async (formDataLocal, page = 1) => {
    setIsLoading(true);
    try {
      const formDataWithPaging = {
        ...formDataLocal,
        pageNumber: page,
        pageSize: 10,
      };

      const response = await fetch(
        `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/filterSpareParts?pageNumber=${page}&pageSize=10`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formDataWithPaging),
        }
      );

      const result = await response.json();
      const data = result.result.data || [];

      setFilteredPartsList(data);
      setDisplayedParts(data);
      setIsFilterDropdownActive(true);
      setIsFiltered(true);
      setCurrentFilteredPage(page);
      setTotalPages(result.result.totalPages || 1);
      setTotalItems(result.result.totalItems || data.length);
    } catch (error) {
      console.error("❌ Error submitting filter:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!isFiltered) {
      fetchParts(currentPage);
    }
  }, [currentPage, isFiltered]);

  const handlePageChange = (newPage) => {
    if (isFiltered && isGCSearch) {
      // Assuming handleFilteringGC is defined elsewhere
      handleFilteringGC(activeSearchTerm, newPage);
    } else if (isFilterDropdownActive) {
      handleFilterSubmitFromDropdown(formData, newPage);
    } else {
      setCurrentPage(newPage);
    }
  };

  const partsToDisplay = displayedParts;
  console.log("partsToDisplay", partsToDisplay);

  return (
    <div style={{ paddingTop: "90px" }}>
      <Row className="p-4">
        <Col xs={12}>
          <SearchBar
            placeholder="Enter part number or GC#"
            tag="spareparts"
            part={(data) => {
              setPartsList([data]);
              setDisplayedParts([data]);
              setCurrentPage(1);
              setTotalPages(1);
            }}
            partsList={(data) => {
              setFilteredPartsList(data.data);
              setDisplayedParts(data.data);
              setIsFiltered(true);
              setIsGCSearch(true);
              setActiveSearchTerm(data.mlfb || "");
            }}
            setTableView={setViewToggled}
            getTotalPages={setTotalPages}
            onGCSearch={(mlfb) => handleFilteringGC(mlfb, 1)}
            setGCSearchState={() => {
              setIsFiltered(true);
              setIsGCSearch(true);
            }}
          />
        </Col>

        <Col xs={12} md={3} className="mt-4 p-3 border rounded shadow-sm" style={{ position: "sticky", top: "90px" }}>
          <PartsFilter
            setFormData={setFormData}
            getSearchValue={setSearchTerm}
            onFilterResult={(apiResult, page) => {
              const data = apiResult?.result?.data || [];
              setFilteredPartsList(data);
              setDisplayedParts(data);
              setIsFilterDropdownActive(true);
              setIsFiltered(true);
              setCurrentFilteredPage(page);
              setTotalPages(apiResult?.result?.totalPages || 1);
              setTotalItems(apiResult?.result?.totalItems || data.length);
            }}
            onSubmitFilter={handleFilterSubmitFromDropdown}
          />
        </Col>

        <Col xs={12} md={9} className="mt-4">
          <div style={{ overflowY: "auto", maxHeight: "calc(100vh - 200px)" }}>
            <MyPagination
              currentPage={isFiltered ? currentFilteredPage : currentPage}
              totalPages={totalPages}
              onPageChange={handlePageChange}
            />

            {totalItems > 0 && (
              <div className="text-end text-muted small mt-2">
                Showing {(currentFilteredPage - 1) * 10 + 1}–
                {Math.min(currentFilteredPage * 10, totalItems)} of {totalItems} results
              </div>
            )}

            {isLoading ? (
                <div
                  className="d-flex justify-content-center align-items-center"
                  style={{ height: "5%", marginTop: "50px" }}
                >
                  <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </Spinner>
                </div>
              ) : partsToDisplay.length === 0 ? (
                <p
                  style={{
                    textAlign: "center",
                    color: "#888",
                    marginTop: "50px",
                  }}
                >
                  No parts to display.
                </p>
              ) : viewToggled ? (
                partsToDisplay.map((part, idx) => (
                  <SparePartListItem
                    key={`${part.partnumber}-${idx}`}
                    id={part.partnumber}
                    partNumber={part.partnumber}
                    name={part.description}
                    price={part.price}
                    kit={part.isKit}
                  />
                ))
              ) : (
                partsToDisplay.map((part, idx) => (
                  <ListView
                    key={`${part.partnumber}-${idx}`}
                    id={part.partnumber}
                    partNumber={part.partnumber}
                    name={part.description}
                    kit={part.isKit}
                    price={part.price}
                    mlfb={part.mlfb}
                    itemCategory={part.itemCategory}
                    note={part.note}
                    productCategory={part.productCategory}
                    subProductCategory={part.subProductCategory}
                  />
                ))
              )}
          </div>
        </Col>
      </Row>
    </div>
  );
}

export default SearchParts;
