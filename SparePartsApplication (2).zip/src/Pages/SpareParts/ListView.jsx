import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { toast } from "react-toastify";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { addItem } from "../../Redux/cartSlice";

function ListView(props) {
  const dispatch = useDispatch();
  const USDollar = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  });

  const handleAddtoBasket = () => {
    dispatch(
      addItem({
        id: props.id,
        name: props.name,
        partNumber: props.partNumber,
        price: props.price,
        quantity: 1,
      })
    );
    toast.success(`Added ${props.name} to Cart`, { position: "bottom-right" });
  };

  return (
    <Card className="grid grid-cols-12 gap-4 p-4 border border-gray-200 shadow-sm rounded-xl my-3 hover:shadow-md transition-shadow">
      {/* Image */}
      <div className="col-span-2">
        <img
          src={`https://stasptusedvapp.blob.core.windows.net/part-images/${props.partNumber}.JPG`}
          alt={props.name}
          className="w-full h-full object-cover rounded-md border border-gray-200"
          onError={(e) => {
            e.currentTarget.onerror = null;
            e.currentTarget.src = "/No_Image_Available.jpg";
          }}
        />
      </div>

      {/* Main Info */}
      <CardContent className="col-span-10 flex flex-col justify-between p-0">
        {/* Top Row */}
        <div className="grid grid-cols-12 gap-4">
          <div className="col-span-9">
            <h3 className="text-sm font-semibold text-neutral-900 leading-tight">
              {props.name}
            </h3>
            <p className="text-xs text-neutral-600">{props.partNumber}</p>
          </div>
          <div className="col-span-3 text-right">
            <p className="text-sm text-neutral-800 font-medium">
              {USDollar.format(props.price)}
            </p>
            <p className="text-xs text-neutral-500">MLFB: {props.mlfb}</p>
          </div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-12 gap-4 mt-2">
          <div className="col-span-9 space-y-0.5">
            {props.note && (
              <p className="text-xs text-neutral-500 italic">
                Note: {props.note}
              </p>
            )}
            <p className="text-xs text-neutral-500">
              Product Category: {props.productCategory} &nbsp;|&nbsp; Item
              Category: {props.itemCategory} |&nbsp; Sub Product Category:{" "}
              {props.subProductCategory}
            </p>
          </div>

          {/* Actions */}
          <div className="col-span-3 flex justify-end items-end gap-3">
            <Link
              to={`/details/${props.partNumber}`}
              className="text-xs text-blue-600 hover:underline font-medium"
            >
              View Details
            </Link>
            <Button
              onClick={handleAddtoBasket}
              variant="outline"
              size="sm"
              className="text-sm font-medium border-gray-300 hover:border-gray-400 hover:bg-gray-50 transition-all"
            >
              + Add to Invoice
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default ListView;
