import React, { useEffect, useState } from "react";
import {
  Table,
  Button,
  Row,
  Col,
  Container,
  Spinner,
  Card,
} from "react-bootstrap";
import { useParams } from "react-router-dom";

const ItemDetailsPage = () => {
  const { partNumber } = useParams();
  const [part, setPart] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  //URLS
  const SPAREPARTSAPI_BASE_URL =
    "https://wea-spt-use-dv-sparepartsapi-001.azurewebsites.net";

  const USDollar = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  });

  useEffect(() => {
    const fetchPart = async () => {
      try {
        const response = await fetch(
          `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetSparePartByPartNumber?partNumber=${partNumber}`
        );
        const data = await response.json();
        if (!data.result) {
          throw new Error("No part found.");
        }
        setPart(data.result);
      } catch (e) {
        setError(e.message);
      } finally {
        setIsLoading(false);
      }
    };
    fetchPart();
  }, [partNumber]);

  const headers = [
    { label: "Part No", key: "partnumber" },
    { label: "Description", key: "description" },
    { label: "Price", key: "price" },
    { label: "Costs", key: "costs" },
    { label: "VED", key: "ved" },
    { label: "Aton Status", key: "atonStatus" },
    { label: "Maxum", key: "maxum" },
    { label: "MLFB", key: "mlfb" },
    { label: "Item Category", key: "itemCategory" },
    { label: "Product Category", key: "productCategory" },
    { label: "Sub Product Category", key: "subProductCategory" },
    { label: "Note", key: "note" },
    { label: "Internal Note", key: "internalNote" },
  ];

  return (
    <div
      style={{
        maxWidth: "90%",
        margin: "0 auto",
        padding: "20px",
        marginTop: "50px",
      }}
    >
      <Container
        className="mt-5 p-4 bg-white shadow-sm rounded"
        style={{ maxWidth: "90%" }}
      >
        {isLoading ? (
          <div className="text-center py-5">
            <Spinner animation="border" variant="primary" />
            <p className="mt-2">Loading part details...</p>
          </div>
        ) : error ? (
          <div className="text-center text-danger">{error}</div>
        ) : (
          <Row className="align-items-center">
            {/* Product Image */}
            <Col md={4} className="d-flex justify-content-center">
              <Card className="border-0 shadow-sm p-3">
                <Card.Img
                  variant="top"
                  src={`https://stasptusedvapp.blob.core.windows.net/part-images/${part.partnumber}.JPG`}
                  alt={part.description}
                  className="img-fluid rounded"
                />
              </Card>
            </Col>

            {/* Product Details */}
            <Col md={5}>
              <h3
                className="mb-3 text-secondary"
                style={{ fontFamily: "Segoe UI, Tahoma, Geneva, sans-serif" }}
              >
                {part.description}
              </h3>
              <Table hover bordered className="table-sm">
                <tbody>
                  {headers.map((header, index) => (
                    <tr key={index}>
                      <th
                        className="bg-light text-secondary"
                        style={{
                          fontFamily: "Segoe UI, Tahoma, Geneva, sans-serif",
                        }}
                      >
                        {header.label}
                      </th>
                      <td
                        className="fw-semibold"
                        style={{
                          fontFamily: "Segoe UI, Tahoma, Geneva, sans-serif",
                        }}
                      >
                        {part[header.key] || "N/A"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Col>

            {/* Price & Actions */}
            <Col md={3} className="text-center">
              <Card className="p-4 shadow-sm border-0">
                <h4
                  className="text-success mb-3"
                  style={{ fontFamily: "Segoe UI, Tahoma, Geneva, sans-serif" }}
                >
                  Price:{" "}
                  <span className="fw-bold">{USDollar.format(part.price)}</span>
                </h4>
                <Button
                  variant="success"
                  className="w-100 py-2 fw-semibold"
                  style={{
                    backgroundColor: "#107C10", // Custom Microsoft green
                    border: "none",
                    fontFamily: "Segoe UI, Tahoma, Geneva, sans-serif",
                    boxShadow: "0px 2px 5px rgba(0, 0, 0, 0.1)",
                  }}
                  onMouseOver={(e) =>
                    (e.target.style.backgroundColor = "#0c5a05")
                  } // Hover effect
                  onMouseOut={(e) =>
                    (e.target.style.backgroundColor = "#107C10")
                  }
                >
                  Add to Invoice
                </Button>
              </Card>
            </Col>
          </Row>
        )}
      </Container>
    </div>
  );
};

export default ItemDetailsPage;
