import React from "react";
import Header from "./Header";
import HeroSection from "./HeroSection";
import AboutSection from "./AboutSection";
import ServicesSection from "./ServicesSection";
import ContactSection from "./ContactSection";
import Footer from "./Footer";

import { Container } from "react-bootstrap";
import FeaturesSection from "./FeaturesSection";
import Base from "../../components/Layouts/Base/Base";
import "./Home.css";

function Home() {
  return (
    <div style={{ marginTop: "90px", overflowX: "hidden" }}>
      <HeroSection />
      <FeaturesSection />
      <ContactSection />
      <Footer />
    </div>
  );
}

export default Home;
