import React from "react";
import { Container, Row, Col } from "react-bootstrap";

function Footer() {
  return (
    <footer className="bg-dark text-white text-center py-3">
      <Container>
        <Row>
          <Col>
            <p>
              &copy; {new Date().getFullYear()} Valmet Inc. All rights
              reserved.
            </p>
            <p>
              <a href="#privacy-policy" className="text-white">
                Privacy Policy
              </a>{" "}
              |
              <a href="#terms-of-service" className="text-white">
                {" "}
                Terms of Service
              </a>
            </p>
          </Col>
        </Row>
      </Container>
    </footer>
  );
}

export default Footer;
