import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";

function ServicesSection() {
  return (
    <Container id="services" className="my-5">
      <h2 className="text-center mb-4">Our Services</h2>
      <Row>
        <Col md={4}>
          <Card>
            <Card.Body>
              <Card.Title>Service One</Card.Title>
              <Card.Text>
                Description of service one. Explain what this service offers and
                how it benefits the client.
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card>
            <Card.Body>
              <Card.Title>Service Two</Card.Title>
              <Card.Text>
                Description of service two. Provide details on this service and
                its advantages.
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card>
            <Card.Body>
              <Card.Title>Service Three</Card.Title>
              <Card.Text>
                Description of service three. Outline what this service entails
                and how it can help the client.
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default ServicesSection;
