import React from "react";
import { Container, Row, Col, Button } from "react-bootstrap";

function HeroSection() {
  return (
    <Container
      fluid
      className="hero-section bg-success text-white py-5"
      style={{ background: "linear-gradient(to right, #005a32, #008c5e)" }}
    >
      <Row className="align-items-center text-center">
        <Col>
          <h1>Valmet SPT Spare Part Online Tool</h1>
          <p className="lead fs-4">
            Find accurate pricing for spare parts and packed columns.
          </p>
          <Button variant="light" size="lg" className="mt-3">
            Learn More
          </Button>
        </Col>
      </Row>
    </Container>
  );
}

export default HeroSection;
