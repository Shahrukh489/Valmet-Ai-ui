import React from "react";
import { Container, Row, Col } from "react-bootstrap";

function AboutSection() {
  return (
    <Container id="about" className="my-5">
      <Row>
        <Col>
          <h2>About Us</h2>
          <p>
            We are a leading company in the industry, offering exceptional
            services and solutions to our clients. Our mission is to deliver
            high-quality results and exceed customer expectations.
          </p>
        </Col>
      </Row>
    </Container>
  );
}

export default AboutSection;
