import React from "react";
import { Container, Row, Col, Card } from "react-bootstrap";

function FeaturesSection() {
  const features = [
    {
      title: "Real-time Pricing",
      description: "Get the latest pricing for all spare parts instantly.",
    },
    {
      title: "Enterprise Integration",
      description: "Seamlessly integrates with your existing systems.",
    },
    {
      title: "Extensibility",
      description: "Endless Possibilities, Make ideas come to life.",
    },
  ];

  return (
    <Container id="features" className="py-5">
      <h2 className="text-center mb-4">Enterprise Features</h2>
      <Row className="g-4">
        {features.map((feature, idx) => (
          <Col md={4} key={idx}>
            <Card className="text-center shadow">
              <Card.Body>
                
                <Card.Title className="mt-3">{feature.title}</Card.Title>
                <Card.Text>{feature.description}</Card.Text>
              </Card.Body>
            </Card>
          </Col>
        ))}
      </Row>
    </Container>
  );
}

export default FeaturesSection;
