import React from "react";
import { Container, Row, Col, Form, Button } from "react-bootstrap";

function ContactSection() {
  return (
    <Container id="contact" className="py-5 bg-light">
      <h2 className="text-center mb-4">Need Help? Contact Us</h2>
      <Row className="justify-content-center">
        {/* Contact Details */}
        <Col md={6} className="mb-4">
          <h4>Shahrukh Sadiq (Ali)</h4>
          <p>
            <strong>Email:</strong>{" "}
            <a href="mailto:shahrukh.sadiq@valmetpartners.com">
              shahrukh.sadiq@valmetpartners.com
            </a>
          </p>
          <p>
            <strong>Phone:</strong>{" "}
            <a href="tel:+18327572651">(832) 757-2651</a>
          </p>
        </Col>

        {/* Contact Details
        <Col md={3} className="mb-4">
          <h4>Michael Frank</h4>
          <p>
            <strong>Email:</strong>{" "}
            <a href="mailto:michael.frank@valmet.com">
              michael.frank@valmet.com
            </a>
          </p>
          <p>
            <strong>Phone:</strong>{" "}
            <a href="tel:+4915238804519">+(491) 5238804519</a>
          </p>
        </Col> */}
      </Row>

      
        {/* <Form>
            <Form.Group className="mb-3" controlId="name">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter your name"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="email">
              <Form.Label>Email</Form.Label>
              <Form.Control
                type="email"
                placeholder="Enter your email"
                required
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="message">
              <Form.Label>Message</Form.Label>
              <Form.Control
                as="textarea"
                rows={4}
                placeholder="How can we help you?"
                required
              />
            </Form.Group>

            <Button variant="success" type="submit" className="w-100">
              Send Message
            </Button>
          </Form> */}
    </Container>
  );
}

export default ContactSection;
