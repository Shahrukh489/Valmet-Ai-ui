import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import i18next from "i18next";
import "./index.css";

import { StateProvider } from "./Redux/stateProvider.jsx";
import reducer, { initialState } from "./Redux/reducer.jsx";
import global_en from "./i18n/en/global_en.json";
import global_fr from "./i18n/fr/global_fr.json";

import App from "./App.jsx";
import store from "./Redux/store.js";
import { Provider } from "react-redux";

// 🆕 Add this import
import { AuthProvider } from "./contexts/AuthContext.jsx";

i18next.init({
  interpolation: { escapeValue: false },
  lng: "en",
  en: {
    global_en,
  },
  fr: {
    global_fr,
  },
});

ReactDOM.createRoot(document.getElementById("root")).render(
  <Provider store={store}>
    <ToastContainer />
    <BrowserRouter>
      {/* 🆕 Wrap App in UserProvider */}
      <AuthProvider>
        <App />
      </AuthProvider>
    </BrowserRouter>
  </Provider>
);
