
import data from "../../mock/data.json";
import Table from "react-bootstrap/Table";


import TableRowComponent from "./TableRowComponent";
import { Link } from "react-router-dom";

function TableComp(props) {
  
  return (
    <Table
      striped
      bordered
      hover
      size="sm"
      className="p-0 mt-1"
      
    >
      <thead>
        <tr>
          <th>Item Name</th>
          <th>Price</th>
        
        </tr>
      </thead>
      
      <tbody>
        {data
          .filter((val) => {
            if (props.search == "") {
              return val;
            } else if (
              val.item_name.toLowerCase().includes(props.search.toLowerCase())
            ) {
              return val;
            }
          })
          .map((item) => {
            return (   
                <TableRowComponent key={item.id} item={item}/>

            );
            
          })}
          </tbody>
    </Table>
  );
}

export default TableComp;
