import React from "react";
import { Container, Col, Button } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import { useState, useEffect } from "react";
import Spinner from "react-bootstrap/Spinner";

const BASE_URL =
  "https://wea-spt-use-dv-configurationsapi-001.azurewebsites.net/";

//TODO: add link to get all filters

function Filterbox(props) {
  //options Array
  const [options, setOptions] = useState([]);
  const [filters, setFilters] = useState([]);
  const [validated, setValidated] = useState(false);

  const [isLoading, setIsLoading] = useState(false);

  //Next item selection selection Disablers
  const [diameterDisabled, setDiameterDisabled] = useState(false);
  const [lengthDisabled, setLengthDisabled] = useState(true);
  const [tubingDisabled, setTubingDisabled] = useState(true);
  const [meshDisabled, setMeshDisabled] = useState(true);
  const [liquidDisabled, setLiquidDisabled] = useState(true);
  const [loadDisabled, setLoadDisabled] = useState(true);
  const [fillingDisabled, setFillingDisabled] = useState(true);

  const [buttonDisabled, setButtonDisabled] = useState(true);

  //MLFB array
  const [mlfbArray, setMLFBArray] = useState([]);

  //Form Data
  const [formData, setFormData] = useState([]);

  useEffect(() => {
    const fetchOptions = async () => {
      setIsLoading(true);

      try {
        const response = await fetch(`${BASE_URL}v1/configurations`);
        const options = await response.json();
        setOptions(options.result);
        console.log(options);

        const filtersResponse = await fetch(
          `${BASE_URL}v1/configurations/filters`
        );
        const filters = await filtersResponse.json();
        setFilters(filters.result);
      } catch (e) {
        setError(e);
      } finally {
        setIsLoading(false);
      }
    };
    fetchOptions();
  }, []);

  useEffect(() => {
    if (props.partNumberOptions.length === 7) {
      setDiameterDisabled(true); // Enable the diameter selection when 7 objects exist
      setButtonDisabled(false)
    }
  }, [props.partNumberOptions]); // Run this effect whenever partNumberOptions changes

  useEffect(() => {
    const setMLFB = async () => {
      try {
        const response = await fetch(
          "https://wea-spt-use-dv-configurationsapi-001.azurewebsites.net/generateMLFBString",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(mlfbArray),
          }
        )
          .then((response) => response.json())
          .then((parsedJSON) => props.setMLFBArray(parsedJSON.result));
      } catch (e) {
        //setError(e)
      } finally {
        setIsLoading(false);
      }
    };

    setMLFB();
  }, [mlfbArray]);

  if (false) {
    return <div>Something Went wrong! try again</div>;
  }

  if (isLoading) {
    return (
      <div>
        <Spinner
          animation="border"
          role="status"
          style={{ marginRight: "auto" }}
        >
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log("Form submitted:", formData);
    props.setGenerateConfiguration(formData);
    console.log(formData.length);
  };

  const changeHandler = (event) => {
    handleConfiguration(event);
    handleDisables(event);
    mlfbHandler(event);
  };

  const mlfbHandler = (event) => {
    //console.log(event.target.value);
    const optionId = parseInt(event.target.value);
    const option = options.find((o) => o.id === optionId);
    //console.log(option)
    setMLFBArray([...mlfbArray, option.code]);
  };

  const searchConfigurationHandler = (event) => {
    props.getConfiguration();
  };
  const handleRestart = () => {
    window.location.reload(false);
  };

  const handleDisables = (event) => {
    const optionId = parseInt(event.target.value);
    const option = options.find((o) => o.id === optionId);
    //console.log(option)
    if (props.partNumberOptions.length === 0) {
      switch (option.optionName) {
        case "Diameter":
          setDiameterDisabled(true);
          setLengthDisabled(false);
          break;
        case "Length":
          setLengthDisabled(true);
          setTubingDisabled(false);
          break;
        case "Tubing":
          setTubingDisabled(true);
          setMeshDisabled(false);
          break;
        case "Mesh":
          setMeshDisabled(true);
          setFillingDisabled(false);
          break;
        case "Filling":
          setFillingDisabled(true);
          setLiquidDisabled(false);
          break;
        case "Liquid":
          setLiquidDisabled(true);
          setLoadDisabled(false);
          break;
        case "Load":
          setLoadDisabled(true);
          setButtonDisabled(false);
          break;

        default:
          return null;
      }
    }
    if (props.partNumberOptions.length === 7) {
      switch (option.optionName) {
        case "Diameter":
          setButtonDisabled(false);
          break;

        default:
          return null;
      }
    } else {
      switch (option.optionName) {
        case "Diameter":
          setDiameterDisabled(true);
          setLengthDisabled(false);
          break;
        case "Length":
          setLengthDisabled(true);
          setTubingDisabled(false);
          break;
        case "Tubing":
          setTubingDisabled(true);
          setButtonDisabled(false);
          break;
        default:
          return null;
      }
    }
  };

  const handleConfiguration = (event) => {
    //Set id to grab object
    const optionId = parseInt(event.target.value);
    const option = options.find((o) => o.id === optionId);
    //console.log(option)

    setFormData((oldArray) => [...oldArray, option]);

    console.log(formData);

    //Find selected option in filters
    const changes = filters.filter(
      (f) =>
        f.selectedOption === option.code &&
        f.groupNumber === option.groupCode &&
        f.filterType === "E"
    );
    // console.log(changes)

    //Remove opions from the options array
    changes.forEach((f) => {
      const index = options.findIndex((o) => {
        return f.filterGroupNumber === o.groupCode && o.code === f.filterOption;
      });

      if (index > -1) {
        options.splice(index, 1);
      }
    });
  };

  return (
    <Container className="p-0">
      <Form noValidate validated={validated} onSubmit={handleSubmit}>
        <div className="mt-4" style={{ textAlign: "center" }}>
          <h6>MAXUM Configurations</h6>
        </div>

        <Col xs={12} className="mb-2 mt-4">
          <Form.Group>
            <Form.Select
              aria-label="Diameter"
              size="sm"
              disabled={diameterDisabled}
              onChange={changeHandler}
              required
            >
              <option defaultValue>Diameter: </option>
              {props.partNumberOptions.length === 7 ? (
                // If there are exactly 7 options, set key and value to index 3
                <option
                  key={props.partNumberOptions[0]?.code}
                  value={props.partNumberOptions[0]?.id}
                  style={{ fontSize: "11px" }}
                  selected
                >
                  {props.partNumberOptions[0]?.code} -{" "}
                  {props.partNumberOptions[0]?.name}
                </option>
              ) : (
                // Default behavior when partNumberOptions is empty
                options
                  .filter((option) => option.groupCode === "8")
                  .map((option) => (
                    <option
                      key={option.code}
                      value={option.id}
                      style={{ fontSize: "11px" }}
                    >
                      {option.code} - {option.name}
                    </option>
                  ))
              )}
            </Form.Select>
          </Form.Group>
        </Col>
        <Col xs={12} className="mb-2 mt-4">
          <Form.Select
            aria-label="Length"
            size="sm"
            disabled={lengthDisabled}
            onChange={changeHandler}
          >
            <option>Length: </option>
            {props.partNumberOptions.length === 7 ? (
              // If there are exactly 7 options, set key and value to index 3
              <option
                key={props.partNumberOptions[1]?.code}
                value={props.partNumberOptions[1]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[1]?.code} -{" "}
                {props.partNumberOptions[1]?.name}
              </option>
            ) : (
              // Default behavior when partNumberOptions is empty
              options
                .filter((option) => option.groupCode === "9")
                .map((option) => (
                  <option
                    key={option.code}
                    value={option.id}
                    style={{ fontSize: "11px" }}
                  >
                    {option.code} - {option.name}
                  </option>
                ))
            )}
          </Form.Select>
        </Col>

        <Col xs={12} className="mb-2 mt-4">
          <Form.Select
            aria-label="Tubing-material"
            size="sm"
            disabled={tubingDisabled}
            onChange={changeHandler}
          >
            <option>Tubing Material: </option>
            {props.partNumberOptions.length === 7 ? (
              // If there are exactly 7 options, set key and value to index 3
              <option
                key={props.partNumberOptions[2]?.code}
                value={props.partNumberOptions[2]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[2]?.code} -{" "}
                {props.partNumberOptions[2]?.name}
              </option>
            ) : (
              // Default behavior when partNumberOptions is empty
              options
                .filter((option) => option.groupCode === "10")
                .map((option) => (
                  <option
                    key={option.code}
                    value={option.id}
                    style={{ fontSize: "11px" }}
                  >
                    {option.code} - {option.name}
                  </option>
                ))
            )}
          </Form.Select>
        </Col>
        <Col xs={12} className="mb-2 mt-4">
          <Form.Select
            aria-label="Mesh-size"
            size="sm"
            disabled={meshDisabled}
            onChange={changeHandler}
          >
            <option>Mesh Size: </option>
            {props.partNumberOptions.length === 7 ? (
              // If there are exactly 7 options, set key and value to index 3
              <option
                key={props.partNumberOptions[3]?.code}
                value={props.partNumberOptions[3]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[3]?.code} -{" "}
                {props.partNumberOptions[3]?.name}
              </option>
            ) : props.partNumberOptions.length === 4 ? (
              // If there are exactly 4 options, set key and value to index 0
              <option
                key={props.partNumberOptions[0]?.code}
                value={props.partNumberOptions[0]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[0]?.code} -{" "}
                {props.partNumberOptions[0]?.name}
              </option>
            ) : (
              // Default behavior when partNumberOptions is empty
              options
                .filter((option) => option.groupCode === "11")
                .map((option) => (
                  <option
                    key={option.code}
                    value={option.id}
                    style={{ fontSize: "11px" }}
                  >
                    {option.code} - {option.name}
                  </option>
                ))
            )}
          </Form.Select>
        </Col>
        <Col xs={12} className="mb-2 mt-4">
          <Form.Select
            aria-label="Filling-material"
            size="sm"
            disabled={fillingDisabled}
            onChange={changeHandler}
          >
            <option>Filling Material: </option>
            {props.partNumberOptions.length === 7 ? (
              // If there are exactly 7 options, set key and value to index 3
              <option
                key={props.partNumberOptions[4]?.code}
                value={props.partNumberOptions[4]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[4]?.code} -{" "}
                {props.partNumberOptions[4]?.name}
              </option>
            ) : props.partNumberOptions.length === 4 ? (
              // If there are exactly 4 options, set key and value to index 0
              <option
                key={props.partNumberOptions[1]?.code}
                value={props.partNumberOptions[1]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[1]?.code} -{" "}
                {props.partNumberOptions[1]?.name}
              </option>
            ) : (
              // Default behavior when partNumberOptions is empty
              options
                .filter((option) => option.groupCode === "A")
                .map((option) => (
                  <option
                    key={option.code}
                    value={option.id}
                    style={{ fontSize: "11px" }}
                  >
                    {option.code} - {option.name}
                  </option>
                ))
            )}
          </Form.Select>
        </Col>
        <Col xs={12} className="mb-2 mt-4">
          <Form.Select
            aria-label="Liquid-phase"
            size="sm"
            disabled={liquidDisabled}
            onChange={changeHandler}
          >
            <option>Liquid Phase: </option>
            {props.partNumberOptions.length === 7 ? (
              // If there are exactly 7 options, set key and value to index 3
              <option
                key={props.partNumberOptions[5]?.code}
                value={props.partNumberOptions[5]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[5]?.code} -{" "}
                {props.partNumberOptions[5]?.name}
              </option>
            ) : props.partNumberOptions.length === 4 ? (
              // If there are exactly 4 options, set key and value to index 0
              <option
                key={props.partNumberOptions[2]?.code}
                value={props.partNumberOptions[2]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[2]?.code} -{" "}
                {props.partNumberOptions[2]?.name}
              </option>
            ) : (
              // Default behavior when partNumberOptions is empty
              options
                .filter((option) => option.groupCode === "B")
                .map((option) => (
                  <option
                    key={option.code}
                    value={option.id}
                    style={{ fontSize: "11px" }}
                  >
                    {option.code} - {option.name}
                  </option>
                ))
            )}
          </Form.Select>
        </Col>

        <Col xs={12} className="mb-4 mt-4">
          <Form.Select
            aria-label="Load"
            size="sm"
            disabled={loadDisabled}
            onChange={changeHandler}
          >
            <option>Load: </option>

            {props.partNumberOptions.length === 7 ? (
              // If there are exactly 7 options, set key and value to index 3
              <option
                key={props.partNumberOptions[6]?.code}
                value={props.partNumberOptions[6]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[6]?.code} -{" "}
                {props.partNumberOptions[6]?.name}
              </option>
            ) : props.partNumberOptions.length === 4 ? (
              // If there are exactly 4 options, set key and value to index 0
              <option
                key={props.partNumberOptions[3]?.code}
                value={props.partNumberOptions[3]?.id}
                style={{ fontSize: "11px" }}
                selected
              >
                {props.partNumberOptions[3]?.code} -{" "}
                {props.partNumberOptions[3]?.name}
              </option>
            ) : (
              // Default behavior when partNumberOptions is empty
              options
                .filter((option) => option.groupCode === "C")
                .map((option) => (
                  <option
                    key={option.code}
                    value={option.id}
                    style={{ fontSize: "11px" }}
                  >
                    {option.code} - {option.name}
                  </option>
                ))
            )}
          </Form.Select>
        </Col>

        <Button
          variant="warning"
          style={{ fontSize: "13px", marginBottom: "23px" }}
          onClick={handleRestart}
        >
          Restart
        </Button>

        <Button
          variant="warning"
          style={{ fontSize: "13px", marginBottom: "20px", marginLeft: "10px" }}
          type="submit"
          disabled={buttonDisabled}
        >
          Generate Configuration
        </Button>
      </Form>
    </Container>
  );
}

export default Filterbox;
