
import React, { useEffect, useState } from 'react'
import ListItem from '../ListItem/ListItem'
import Spinner from 'react-bootstrap/Spinner';
import PackedColumn from '/image.png'


function Possibilities(props) {

    const [topConfigurations, setTopConfigurations] = useState([])
    const [isLoading, setIsLoading] = useState(false);

    const [parsedConfiguration, setParsedConfiguration] = useState([]);

    console.log(props.finalConfig)

    useEffect(() => {

        setIsLoading(true)
        const setConfigurations = async () => {
            try {
                const response = await fetch(
                  "https://wea-spt-use-dv-configurationsapi-001.azurewebsites.net/v1/configurations/getTopConfigurations"
                );
                var x = await response.json()
                console.log(x.result)
                setTopConfigurations(x.result)
            } catch (e) {
                //setError(e)
            } finally {
                setIsLoading(false)
            }
        }
        setConfigurations();
    }, []);

    useEffect(() => {

        setIsLoading(true)
        const setFinalMLFB = async () => {
            try {
                const response = await fetch(
                  "https://wea-spt-use-dv-configurationsapi-001.azurewebsites.net/generateMLFBString",
                  {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                    },
                    body: JSON.stringify(props.mlfbCode),
                  }
                )
                  .then((response) => response.json())
                  .then((parsedJSON) => props.setMLFBArray(parsedJSON.result));
            } catch (e) {
                //setError(e)
            } finally {
                setIsLoading(false)
            }
        }
        setFinalMLFB();
    }, [props.finalConfig]);

    if (isLoading) {
        return (
            <Spinner animation="border" role="status" style={{ alignItems: 'center' }}>
                <span className="visually-hidden">Loading...</span>
            </Spinner>)
    }

    return (
        <div style={{overflow: 'auto', width: '100%', height: '700px'}}>
            {props.finalConfig.length === 0 ? (
                topConfigurations?.map((option) => {
                    return (
                        <ListItem key={option.mlfb} mlfb={option.mlfb} configuration={option.configurations} partNumber={option.partNumber} price={option.price}/>
                    )
                })) : <ListItem configuration={props.finalConfig} mlfb={props.mlfbCode} partNumber={props.partNumber} image={PackedColumn} price={ props.price}/>
            }
            



        </div>
    )
}

export default Possibilities