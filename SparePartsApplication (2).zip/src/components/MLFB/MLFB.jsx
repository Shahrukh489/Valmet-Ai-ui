import React from 'react'
import { useState, useEffect } from 'react';
import { Col, Row } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';

import './MLFB.css'

function MLFB(props) {

    
    return (
        <Row className='align-items-center'>
            <Col xs={8} c>
                <Form.Control
                    type="text"
                    placeholder= {`MLFB: ${props.mlfbCode}`}
                    aria-label="mlfb"
                    readOnly

                    style={{ fontWeight: 'bold',fontSize: "14px", fontFamily: 'sans-serif' }}
                    onClick={() => {navigator.clipboard.writeText(props.mlfbCode), alert("Copied the text: " + props.mlfbCode); }}
                    
                    
                /></Col>

        </Row>

    )
}

export default MLFB 