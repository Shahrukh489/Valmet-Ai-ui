import Container from "react-bootstrap/Container";
import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import NavDropdown from "react-bootstrap/NavDropdown";
import { useMediaQuery } from "@mui/material";
import { useStateValue } from "../../../../Redux/stateProvider";
import { useTheme } from "@mui/material";
import React from "react";
import { useDispatch, useSelector } from "react-redux";
import BugReportIcon from "@mui/icons-material/BugReport";

import "./NavigationBar.css";
import { useAuth } from "../../../../contexts/AuthContext";

import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import LanguageIcon from "@mui/icons-material/Language";
import PermIdentityIcon from "@mui/icons-material/PermIdentity";

import { Link, useNavigate } from "react-router-dom";
import DrawerComp from "../DrawerComp/DrawerComp";

function NavigationBar() {
  const { cartTotalQuantity } = useSelector((state) => state.cart);
  const { user, roles } = useAuth();
  const navigate = useNavigate();
  const theme = useTheme();
  const isMatch = useMediaQuery(theme.breakpoints.down("md"));

  const cart = useSelector((state) => state.cart);

  const isAdminOrManager = roles.some((role) =>
    ["Admin", "Manager"].includes(role)
  );

  return (
    <Navbar
      bg="dark"
      data-bs-theme="dark"
      className="shadow-sm"
      style={{
        position: "fixed", // ✅ changed from sticky
        top: 0,
        left: 0,
        right: 0,
        height: "90px",
        padding: "10px 20px",
        zIndex: 1050,
      }}
    >
      {isMatch ? (
        <DrawerComp />
      ) : (
        <Container fluid>
          <Navbar.Brand href="/">
            <img
              src="/Valmet.png"
              alt=""
              className="img-responsive"
              style={{ width: "150px" }}
            />
          </Navbar.Brand>

          <Nav className="me-auto" style={{ alignItems: "center" }}>
            <Link to={"/search"}>Column Configurator</Link>

            <Link to={"/searchparts"} style={{ marginLeft: "10px" }}>
              Search Parts
            </Link>

            {/* <Link to={"/partsbook"} style={{ marginLeft: "10px" }}>
                  Parts Book
                </Link> */}
          </Nav>

          <Nav style={{ alignItems: "center" }}>
            {isAdminOrManager && (
              <Link to={"/managerportal"}>Manager Portal</Link>
            )}
            <NavDropdown title={<BugReportIcon />} id="basic-nav-dropdown">
              <NavDropdown.Item as={Link} to="/report-a-bug">
                Report a Bug
              </NavDropdown.Item>
              {/* <NavDropdown.Item href="#action/3.2">
                  <span className="fi fi-sg"></span> Singapore
                </NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">
                  <span className="fi fi-de"></span> German
                </NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">
                  <span className="fi fi-fr"></span> France
                </NavDropdown.Item> */}
            </NavDropdown>

            <Link to={"/cart"}>
              <ShoppingCartOutlinedIcon />
              {/* <span className="header_optionLineTwo header_basketCount">
                {cartTotalQuantity}
              </span> */}
              Cart
            </Link>

            <Link
              to={"/login"}
              onClick={() => {
                localStorage.removeItem("user");
                localStorage.removeItem("cartItems");
                location.reload();
              }}
            >
              <PermIdentityIcon />
              Logout
            </Link>
          </Nav>
        </Container>
      )}
    </Navbar>
  );
}

export default NavigationBar;
