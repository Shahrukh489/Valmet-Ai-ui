import { Container } from "react-bootstrap";
import { useEffect, useState } from "react";
import NavigationBar from "./NavigationBar/NavigationBar";
import LoginPage from "../../../Pages/Login/LoginPage";

import "bootstrap/dist/css/bootstrap.min.css";
import "react-toastify/dist/ReactToastify.css";
import "/node_modules/flag-icons/css/flag-icons.min.css";

function Base({ children, className, hideNavbar }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    let user = localStorage.getItem("user");
    if (user) {
      console.log("User exists in storage");
      setIsAuthenticated(true);
    }
  }, [isAuthenticated]);

  return (
    <div
      className={`${className || ""}`}
      style={{
        width: "100vw",
        minHeight: "100vh",
        overflowX: "hidden",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {isAuthenticated ? (
        <>
          {/* Only render Navbar if hideNavbar is false */}
          {!hideNavbar && <NavigationBar />}

          <Container
            className={`base-container ${className || ""} p-0 m-0`}
            fluid
            style={{
              flex: "1", // Makes the container take full remaining height
              width: "100vw",
              maxWidth: "100%",
              padding: 0,
              margin: 0,
            }}
          >
            {children}
          </Container>
        </>
      ) : (
        <LoginPage handleIsAuthenticated={setIsAuthenticated} />
      )}
    </div>
  );
}

export default Base;
