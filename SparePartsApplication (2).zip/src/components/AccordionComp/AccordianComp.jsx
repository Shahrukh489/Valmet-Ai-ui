import React from "react";
import Accordion from "react-bootstrap/Accordion";
import AccordianItem from "./AccordianItem";

function AccordianComp(props) {
  return (
    <Accordion >
  
        <Accordion.Item key={1}>
          <Accordion.Header style={{backgroundColor: 'lightgray'}}></Accordion.Header>
          <Accordion.Body>
            <AccordianItem        
            />
          </Accordion.Body>
        </Accordion.Item>

        <Accordion.Item key={2}>
          <Accordion.Header style={{backgroundColor: 'lightgray'}}></Accordion.Header>
          <Accordion.Body>
            <AccordianItem        
            />
          </Accordion.Body>
        </Accordion.Item>
  
    </Accordion>
  );
}

export default AccordianComp;
