
import Accordion from 'react-bootstrap/Accordion';
import React, { useEffect, useState } from "react";
import { Col, Row } from "react-bootstrap";
import { Button } from "react-bootstrap";
import Spinner from 'react-bootstrap/Spinner';
import { Link } from "react-router-dom";

function Accordian(props) {
  const [chapterSections, setChapterSections] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  
  useEffect(() => {
    const setSections = async () => {
        try {
            const response = await fetch('http://localhost:5034/v1/spareparts/api/spareparts/GetSectionTitles')
            var x = await response.json()
            setChapterSections(x.result)
        } catch (e) {
            //setError(e)
        } finally {
            setIsLoading(false)
        }
    }
    setSections();
  }, []);
  
  if (isLoading) {
    return (
        <Spinner animation="border" role="status" style={{ alignItems: 'center' }}>
            <span className="visually-hidden">Loading...</span>
        </Spinner>)
  }
  return (
    <Accordion>
    <Accordion.Item eventKey="0">
      <Accordion.Header style={{backgroundColor: 'lightgray'}}>Chapter: {props.chapter} - {props.chapterTitles}</Accordion.Header>
      <Accordion.Body>
          {chapterSections?.filter((s) => {
            if(s.itemKey === props.relation) {
              console.log(s)
              return s
            }
          }).map((s) => {
            return(     
              <div style={{fontSize: "13px", fontFamily: "Siemens Sans Black, arial, sans-serif;"}}>
                <Link style={{color: 'black'}}>{s.section} - {s.title}</Link>   
              </div>  
                
            )
          })}
      </Accordion.Body>
    </Accordion.Item>
  </Accordion>
  )
}

export default Accordian