import React from "react";
import TableComp from "../TableComp/TableComp";
import { Button, Container, Col, Row } from "react-bootstrap";
import InputGroup from "react-bootstrap/InputGroup";
import Form from "react-bootstrap/Form";
import { useStateValue } from "../../Redux/stateProvider";
import { toast } from "react-toastify";


function AccordianItem(props) {
    
    const [{ basket }, dispatch] = useStateValue();
    const handleAddtoBasket = () => {
        addToBasket();
        toast.success(`Added} to Cart`, {position: 'bottom-right'})
    }
    const addToBasket = () => {
        //dispatch item to the data layer
        dispatch({
          type: "Add_to_Basket",
          item: {
            
          },
        });
    
        console.log(basket);
      };
  return (
    <Container>
      <Row>
        <Col xs={2}>
          <img
            src="https://m.media-amazon.com/images/I/614ZitKCwHL._AC_SL1500_.jpg"
            alt=""
            style={{ maxWidth: "100px"
                    }}
          />
        </Col>
        <Col xs={4}>
          <p>
            Description: Lorem ipsum dolor sit amet
          </p>
        </Col>

        <Col xs={1} style={{ marginRight: '35px'}}>
          <p>Price: $1000</p>
        </Col>

        <Col
          xs={2}
          style={{  height: "40px" }}
        >
          <InputGroup size="sm">
            <InputGroup.Text id="inputGroup-sizing-sm">Qty</InputGroup.Text>
            <Form.Control
              aria-label="Quantity"
              placeholder="1"
              aria-describedby="inputGroup-sizing-sm"
            />
          </InputGroup>
        </Col>

        <Col
          style={{
            height: "40px",
          }}
          xs={2}
        >
          <Button variant="outline-success" onClick={handleAddtoBasket}>
            Add
          </Button>
        </Col>
      </Row>
    </Container>
  );
}

export default AccordianItem;
