import Form from "react-bootstrap/Form";
import { Button, Modal } from "react-bootstrap";
import { useState } from "react";
import InputGroup from "react-bootstrap/InputGroup";
import SearchIcon from "@mui/icons-material/Search";

function SearchBar(props) {
  const [isLoading, setIsLoading] = useState(false);
  const [parsedConfiguration, setParsedConfiguration] = useState([]);
  const [showErrorModal, setShowErrorModal] = useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [showNotFoundModal, setShowNotFoundModal] = useState(false);
  const [showSparePartNotFoundModal, setShowSparePartNotFoundModal] =
    useState(false);

  const SPAREPARTSAPI_BASE_URL =
    "https://wea-spt-use-dv-sparepartsapi-001.azurewebsites.net";

  async function handleParse(e) {
    try {
      e.preventDefault();
      const searchInput = e.target[0].value.toUpperCase();

      // GC search
      if (props.tag === "spareparts") {
        if (searchInput.includes("7KQ3118")) {
          const encodedSearchTerm = encodeURIComponent(searchInput);
          props.setGCSearchState?.();
          props.onGCSearch?.(encodedSearchTerm);
          
          return;
        }

        // Regular part number search
        const URL = `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetSparePartByPartNumber?partNumber=${searchInput}`;
        const response = await fetch(URL);
        const x = await response.json();

        if (!x.result || Object.keys(x.result).length === 0) {
          setShowSparePartNotFoundModal(true);
        } else {
          props.part(x.result);
        }
      }

      // Price update search
      if (props.tag === "priceupdate") {
        const URL = `${SPAREPARTSAPI_BASE_URL}/v1/spareparts/api/spareparts/GetSparePartByPartNumber?partNumber=${searchInput}`;
        const response = await fetch(URL);
        const x = await response.json();

        if (!x.result || Object.keys(x.result).length === 0) {
          setShowSparePartNotFoundModal(true);
        } else {
          props.part(x.result);
        }
      }

      // Config column search
      const configURL = `https://wea-spt-use-dv-configurationsapi-001.azurewebsites.net/v1/configurations/getPackedColumn?partNumber=${searchInput}`;
      if (
        searchInput.includes("COL") ||
        searchInput.includes("A6X") ||
        searchInput.includes("US2") ||
        searchInput.includes("2021")
      ) {
        const response = await fetch(configURL);
        const x = await response.json();
        props.getPreSetOptions(x.result.options || []);

        if (x.result.errors?.length > 0) {
          showErrorModalWithErrors(x.result.errors);
        }

        if (!x.result.options || x.result.options.length === 0) {
          setShowNotFoundModal(true);
        }
      }

      // Parse string
      if (searchInput.includes("7KQ2908")) {
        const encodedSearchTerm = encodeURIComponent(searchInput);
        const response = await fetch(
          `https://wea-spt-use-dv-configurationsapi-001.azurewebsites.net/v1/configurations/parseMLFBString?mlfb=${encodedSearchTerm}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
          }
        );
        const x = await response.json();
        props.getPreSetOptions(x.result || []);
        setParsedConfiguration(x.result);
        props.result(x.result);
      } else {
        const response = await fetch(configURL, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(props.data),
        });
        const parsedJSON = await response.json();
        setParsedConfiguration(parsedJSON.result);
        props.result(parsedJSON.result);
      }
    } catch (e) {
      console.error("Error:", e);
    }
  }

  const showErrorModalWithErrors = (errors) => {
    setErrorMessages(errors);
    setShowErrorModal(true);
  };

  const handleCloseModal = () => setShowErrorModal(false);
  const handleCloseNotFoundModal = () => setShowNotFoundModal(false);
  const handleCloseSparePartNotFoundModal = () =>
    setShowSparePartNotFoundModal(false);

  return (
    <div>
      <Form className="d-flex" style={{ width: "92%" }} onSubmit={handleParse}>
        <InputGroup.Text>
          <SearchIcon />
        </InputGroup.Text>
        <Form.Control
          type="search"
          placeholder={props.placeholder}
          aria-label="Search"
        />
        <Button variant="warning" type="submit" style={{ marginLeft: "5px" }}>
          Search
        </Button>
      </Form>

      {/* Error Modal */}
      <Modal show={showErrorModal} onHide={handleCloseModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Error Finding Binds</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {errorMessages.length > 0 ? (
            errorMessages.map((error, index) => (
              <p key={index} className="text-danger">
                {error}
              </p>
            ))
          ) : (
            <p>No specific error messages.</p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Column Not Found Modal */}
      <Modal
        show={showNotFoundModal}
        onHide={handleCloseNotFoundModal}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Column Not Found</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>
            The requested column was not found. Please try a different search.
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseNotFoundModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Spare Part Not Found Modal */}
      <Modal
        show={showSparePartNotFoundModal}
        onHide={handleCloseSparePartNotFoundModal}
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Spare Part Not Found</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>
            The spare part you searched for could not be found. Please check the
            part number and try again.
          </p>
        </Modal.Body>
        <Modal.Footer>
          <Button
            variant="secondary"
            onClick={handleCloseSparePartNotFoundModal}
          >
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}

export default SearchBar;
