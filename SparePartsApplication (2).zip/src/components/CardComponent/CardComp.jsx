import React, { useState } from "react";

import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";

import { Link, useParams } from "react-router-dom";
//image 600 x 800

function CardComp(props) {
  return (
    <Card className="card" border="light" style={{ textAlign: "center" }}>
      <Card.Img
        variant="top"
        src={props.image}
        style={{
          margin: 'auto',
          height: "100px",
          width: "100px",
        }}
      />
      <Card.Body>
        <h6 >{props.name}</h6>
        <div>
          <h5>${props.price}</h5>
          <Link to={`/itemdetails/${props.id}`}>
            <Button variant="outline-success" size="sm">
              See Details
            </Button>
          </Link>
        </div>
      </Card.Body>
    </Card>
  );
}
export default CardComp;
